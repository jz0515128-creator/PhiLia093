package org.xilian.xilianai;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Observes visible text of the official Douyin app and, only after the user has asked for it,
 * types one generated reply into the group-chat composer and taps Send.
 *
 * Sending rules (all enforced here or in ObserverControl, not just in the UI):
 *  - only the Douyin package, only a page that looks like a group chat with an input box;
 *  - only a reply the user confirmed, or any reply while the user has switched automatic mode on;
 *  - never over text the user already typed; the composer must contain exactly our text before Send;
 *  - cooldown and hourly cap; pending replies expire after two minutes;
 *  - no gestures, no navigation, no reading of password fields.
 */
public class DouyinAccessibilityService extends AccessibilityService {
    // Mainland Douyin and common international TikTok package IDs.
    // Accessibility events are still limited to these apps by the service XML.
    private static final Set<String> SUPPORTED_CHAT_PACKAGES = new LinkedHashSet<>(Arrays.asList(
            "com.ss.android.ugc.aweme", // Douyin (mainland China)
            "com.zhiliaoapp.musically", // TikTok international
            "com.ss.android.ugc.trill"  // TikTok regional builds
    ));
    private static final int MAX_NODES = 700;
    private static final int MAX_SNAPSHOTS = 10;
    private static final long TICK_MS = 700L;
    private static final long OBSERVATION_POLL_MS = 1_000L;
    private static final long COMPOSER_WAIT_MS = 20_000L;
    private static final long SEND_BUTTON_WAIT_MS = 6_000L;
    private static final String PARTIAL_STATUS =
            "可见文字片段（不保证消息完整，发送者可能无法识别）";
    private static final Pattern GROUP_MEMBER_COUNT = Pattern.compile(".*(?:等\\s*)?\\d+\\s*人.*");
    private static final Pattern TIME_LIKE = Pattern.compile(
            "^(?:刚刚|\\d+\\s*(?:秒|分钟|小时|天)前"
                    + "|(?:(?:今天|昨天|前天|凌晨|上午|中午|下午|晚上|星期[一二三四五六日天]|周[一二三四五六日天]"
                    + "|\\d{1,4}[-/年.]\\d{1,2}(?:[-/月.]\\d{0,2}日?)?)\\s*)?"
                    + "\\d{1,2}[:：]\\d{2}(?:[:：]\\d{2})?)$");

    private static final String SESSION_ID = "douyin-chat";

    private static volatile DouyinAccessibilityService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, List<String>> lastSnapshots = new HashMap<>();
    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            tickScheduled = false;
            tickPending();
        }
    };
    private final Runnable observationPollRunnable = new Runnable() {
        @Override
        public void run() {
            observationPollScheduled = false;
            if (!ObserverControl.isObservingEnabled(DouyinAccessibilityService.this)) {
                return;
            }
            observeActiveWindow("poll", 0);
        }
    };

    private boolean tickScheduled;
    private boolean observationPollScheduled;
    private int consecutiveWindowMisses;
    private long lastSeenBaselineResetGeneration = -1L;
    private String lastConversationSignature = "";
    private String stageToken = "";
    private int stage; // 0 = nothing typed yet, 1 = our text typed, waiting to tap Send
    private long stageStartedAt;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        lastSnapshots.clear();
        lastConversationSignature = "";
        lastSeenBaselineResetGeneration = ObserverControl.getBaselineResetGeneration(this);
        String status = ObserverControl.isObservingEnabled(this)
                ? "系统服务已连接；正在等待抖音群聊页面"
                : "系统服务已连接；App 内观察开关目前暂停";
        ObserverControl.setServiceState(this, true, status);
        if (ObserverControl.hasOutgoing(this)) {
            scheduleTick(TICK_MS);
        }
        if (ObserverControl.isObservingEnabled(this)) {
            scheduleObservationPoll(0L);
        }
    }

    /** Called from Python when the user enables observation while the service is already connected. */
    public static void requestObservationPoll() {
        final DouyinAccessibilityService service = instance;
        if (service != null) {
            service.handler.post(new Runnable() {
                @Override
                public void run() {
                    if (ObserverControl.isObservingEnabled(service)) {
                        service.lastSnapshots.clear();
                        service.lastConversationSignature = "";
                        service.consecutiveWindowMisses = 0;
                        service.scheduleObservationPoll(0L);
                        ObserverControl.setServiceState(service, true,
                                "已收到开始观察指令；正在检查当前前台窗口");
                    }
                }
            });
        }
    }

    /** Called from Python right after a reply is queued so sending starts without waiting for an event. */
    public static void requestTick() {
        final DouyinAccessibilityService service = instance;
        if (service != null) {
            service.handler.post(new Runnable() {
                @Override
                public void run() {
                    service.scheduleTick(0L);
                }
            });
        }
    }

    @Override
    public void onInterrupt() {
        handler.removeCallbacks(tickRunnable);
        handler.removeCallbacks(observationPollRunnable);
        tickScheduled = false;
        observationPollScheduled = false;
        ObserverControl.clearOutgoing(this);
        ObserverControl.setServiceState(this, false,
                "Android 系统中断了观察服务；待发回复已取消，请检查无障碍设置");
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        handler.removeCallbacks(tickRunnable);
        handler.removeCallbacks(observationPollRunnable);
        tickScheduled = false;
        observationPollScheduled = false;
        lastSnapshots.clear();
        lastConversationSignature = "";
        ObserverControl.clearOutgoing(this);
        instance = null;
        ObserverControl.setServiceState(this, false,
                "系统辅助功能服务已断开；没有后台读取");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tickRunnable);
        handler.removeCallbacks(observationPollRunnable);
        tickScheduled = false;
        observationPollScheduled = false;
        lastSnapshots.clear();
        lastConversationSignature = "";
        ObserverControl.clearOutgoing(this);
        instance = null;
        ObserverControl.setServiceState(this, false,
                "系统辅助功能服务已停止；没有后台读取");
        super.onDestroy();
    }

    // ------------------------------------------------------------------ observing

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) {
            return;
        }
        if (!isSupportedChatPackage(event.getPackageName().toString())) {
            return;
        }
        if (ObserverControl.hasOutgoing(this)) {
            scheduleTick(TICK_MS);
        }
        if (!ObserverControl.isObservingEnabled(this)) {
            // A pause is a hard baseline boundary. Do not diff against messages that arrived
            // while the user had observation disabled when they later resume.
            lastSnapshots.clear();
            lastConversationSignature = "";
            handler.removeCallbacks(observationPollRunnable);
            observationPollScheduled = false;
            if (!ObserverControl.hasOutgoing(this)) {
                ObserverControl.setServiceState(this, true, "观察已暂停；未读取或保存抖音文字");
            }
            return;
        }

        int eventType = event.getEventType();
        // Entering a new Activity/page is a strong boundary. Start with a baseline rather
        // than accidentally answering visible history from the previous page.
        if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastSnapshots.clear();
            lastConversationSignature = "";
        }
        observeActiveWindow("event", eventType);
    }

    /**
     * Process the currently visible target app. On a recognized group page we keep a lightweight
     * foreground poll running: some app versions emit incomplete/coalesced accessibility events.
     * Polling stops automatically when the target group page is no longer the active visible page.
     */
    private void observeActiveWindow(String source, int eventType) {
        AccessibilityNodeInfo root = null;
        try {
            long resetGeneration = ObserverControl.getBaselineResetGeneration(this);
            if (resetGeneration != lastSeenBaselineResetGeneration) {
                lastSnapshots.clear();
                lastConversationSignature = "";
                lastSeenBaselineResetGeneration = resetGeneration;
                ObserverControl.setServiceState(this, true,
                        "观察状态发生变化；当前页面将重新建立基线");
            }
            root = getSupportedWindowRoot();
            if (root == null) {
                consecutiveWindowMisses++;
                ObserverControl.setServiceState(this, true,
                        "观察轮询运行中，但当前未取得受支持的抖音窗口（连续 "
                                + consecutiveWindowMisses + " 次）；会继续每秒检查，切到抖音群聊即可");
                // Do not stop after three misses. The user may enable observation while
                // the app itself is foreground, then switch to Douyin after several seconds.
                // A bounded retry silently made the observer permanently inert in that flow.
                scheduleObservationPoll(OBSERVATION_POLL_MS);
                return;
            }
            consecutiveWindowMisses = 0;

            // Keep polling even when the current page has not yet passed chat recognition.
            // V5 only scheduled the next poll AFTER successful recognition, so a single
            // false-negative (for example a title positioned below 18% of the root) stopped
            // polling permanently until another accessibility event happened.
            scheduleObservationPoll(OBSERVATION_POLL_MS);
            PageSnapshot page = collectVisibleText(root);
            if (!page.groupMarker || !page.hasComposer) {
                // Do not erase a trustworthy snapshot on a transient false-negative. Clear it
                // only when we can positively identify a different conversation or on an
                // explicit baseline reset/window-state boundary.
                ObserverControl.setServiceState(this, true,
                        "目标抖音窗口可读，但群聊识别未通过：群标记=" + page.groupMarker
                                + "，输入框=" + page.hasComposer
                                + "，可读节点=" + page.nodeCount
                                + "，页头候选=" + page.headerCandidates
                                + "；继续轮询，未触发回复");
                return;
            }

            // If the stable title/header changes, treat it as a different conversation and
            // establish a new baseline. This avoids replying to messages revealed by switching chats.
            if (!page.conversationSignature.isEmpty()) {
                if (!lastConversationSignature.isEmpty()
                        && !lastConversationSignature.equals(page.conversationSignature)) {
                    lastSnapshots.clear();
                    ObserverControl.setServiceState(this, true,
                            "检测到群聊标题变化；已重置基线，避免将旧记录当作新消息");
                }
                lastConversationSignature = page.conversationSignature;
            }

            // Keep polling only while a recognized group-chat window is visible.
            scheduleObservationPoll(OBSERVATION_POLL_MS);

            List<String> visible = new ArrayList<>();
            for (String fragment : page.fragments) {
                if (isSensitiveLike(fragment) || isUiControl(fragment) || isTimeLike(fragment)
                        || isInternalDiagnosticText(fragment)) {
                    continue;
                }
                visible.add(fragment);
            }

            String sessionId = SESSION_ID;
            long now = System.currentTimeMillis();
            List<String> previous = lastSnapshots.get(sessionId);
            if (visible.isEmpty()) {
                if (previous == null) {
                    lastSnapshots.put(sessionId, new ArrayList<String>());
                    ObserverControl.setServiceState(this, true,
                            "群聊已识别，但当前没有可读消息；等待第一份非空页面作为基线");
                } else {
                    // Keep the last trustworthy baseline during transient node-tree gaps.
                    ObserverControl.setServiceState(this, true,
                            "群聊已识别；本次没有可读消息片段，保留上次基线并继续侦测");
                }
                return;
            }
            if (lastSnapshots.size() >= MAX_SNAPSHOTS && previous == null) {
                lastSnapshots.clear();
            }

            int recorded = 0;
            if (previous == null || previous.isEmpty()) {
                lastSnapshots.put(sessionId, new ArrayList<>(visible));
                for (String fragment : visible) {
                    if (!ObserverControl.isOwnRecentText(this, fragment)) {
                        ObserverControl.appendObservation(this, sessionId, "", fragment, now,
                                0.45d, PARTIAL_STATUS, false);
                        recorded++;
                    }
                }
                ObserverControl.setServiceState(this, true,
                        "群聊已识别；当前页面建立基线（" + recorded
                                + " 条），持续侦测后续新消息（可读节点 " + page.nodeCount + "）");
                return;
            }

            List<String> fresh = computeFresh(previous, visible);
            lastSnapshots.put(sessionId, new ArrayList<>(visible));
            for (String fragment : fresh) {
                if (ObserverControl.isOwnRecentText(this, fragment)) {
                    continue;
                }
                ObserverControl.appendObservation(this, sessionId, "", fragment, now,
                        0.45d, PARTIAL_STATUS, true);
                recorded++;
            }
            if (recorded > 0) {
                ObserverControl.setServiceState(this, true,
                        "侦测到 " + recorded + " 条新可见文字；已交给 App 处理（可读节点 "
                                + page.nodeCount + "，来源=" + source + "）");
            } else if (visible.isEmpty()) {
                ObserverControl.setServiceState(this, true,
                        "群聊已识别；目前没有可读消息文字（节点 " + page.nodeCount + "），继续侦测");
            } else if (findOverlap(previous, visible) == 0 && !isExactPrefix(previous, visible)) {
                ObserverControl.setServiceState(this, true,
                        "群聊已识别；页面文字变化但无法安全确认新增项，已更新基线（未触发回复）");
            } else {
                ObserverControl.setServiceState(this, true,
                        "群聊已识别；暂无新消息（可见片段 " + visible.size() + " 条），继续侦测");
            }
        } catch (RuntimeException exception) {
            // Do not expose screen text or sensitive details in status diagnostics.
            ObserverControl.setServiceState(this, true,
                    "读取抖音可见文字发生异常；本次未触发回复，稍后会重试");
            if ("event".equals(source)) {
                scheduleObservationPoll(900L);
            }
        } finally {
            if (root != null) {
                root.recycle();
            }
        }
    }

    private void scheduleObservationPoll(long delayMs) {
        if (!ObserverControl.isObservingEnabled(this)) {
            return;
        }
        if (observationPollScheduled && delayMs > 0L) {
            return;
        }
        handler.removeCallbacks(observationPollRunnable);
        observationPollScheduled = true;
        handler.postDelayed(observationPollRunnable, Math.max(0L, delayMs));
    }

    /**
     * Prefer the active window. If an IME or transient system window owns focus, inspect only
     * visible/focused windows and return a root belonging to a supported target package.
     */
    private AccessibilityNodeInfo getSupportedWindowRoot() {
        AccessibilityNodeInfo active = null;
        AccessibilityNodeInfo selected = null;
        try {
            active = getRootInActiveWindow();
            if (active != null && isDouyinWindow(active)) {
                return active;
            }
            if (active != null) {
                active.recycle();
                active = null;
            }
            List<AccessibilityWindowInfo> windows = getWindows();
            if (windows == null) {
                return null;
            }
            for (AccessibilityWindowInfo window : windows) {
                if (window == null) {
                    continue;
                }
                AccessibilityNodeInfo candidate = null;
                try {
                    if (selected != null || (!window.isActive() && !window.isFocused())) {
                        continue;
                    }
                    candidate = window.getRoot();
                    if (candidate != null && isDouyinWindow(candidate)) {
                        selected = candidate;
                        candidate = null;
                    }
                } finally {
                    if (candidate != null) {
                        candidate.recycle();
                    }
                    window.recycle();
                }
            }
            return selected;
        } catch (RuntimeException ignored) {
            if (active != null) {
                active.recycle();
            }
            if (selected != null) {
                selected.recycle();
            }
            return null;
        }
    }

    // Kept as wrappers for service diagnostics; the pure-Java helper has regression tests.
    static List<String> computeFresh(List<String> previous, List<String> current) {
        return SnapshotDiff.computeFresh(previous, current);
    }

    static int findOverlap(List<String> previous, List<String> current) {
        return SnapshotDiff.findOverlap(previous, current);
    }

    private static boolean isExactPrefix(List<String> previous, List<String> current) {
        return SnapshotDiff.isExactPrefix(previous, current);
    }

    private static boolean isSupportedChatPackage(String packageName) {
        return packageName != null && SUPPORTED_CHAT_PACKAGES.contains(packageName);
    }

    private boolean isDouyinWindow(AccessibilityNodeInfo root) {
        CharSequence name = root.getPackageName();
        return name != null && isSupportedChatPackage(name.toString());
    }

    private PageSnapshot collectVisibleText(AccessibilityNodeInfo root) {
        PageSnapshot snapshot = new PageSnapshot();
        List<PositionedText> found = new ArrayList<>();
        Rect rootBounds = new Rect();
        root.getBoundsInScreen(rootBounds);
        int rootHeightForHeader = Math.max(0, rootBounds.bottom - rootBounds.top);
        // UI layouts differ between Douyin builds, display scaling, status/navigation bars,
        // and accessibility root bounds. V5's 18% cutoff was too strict and rejected valid
        // group headers on some devices. Use a wider header band, but keep message-body text
        // outside it from being accepted as group evidence.
        int groupHeaderBottom = rootHeightForHeader == 0
                ? Integer.MAX_VALUE
                : rootBounds.top + Math.max(1, rootHeightForHeader * 35 / 100);
        int signatureBottom = rootHeightForHeader == 0
                ? Integer.MAX_VALUE
                : rootBounds.top + Math.max(1, rootHeightForHeader * 25 / 100);
        Deque<AccessibilityNodeInfo> pending = new ArrayDeque<>();
        pending.addLast(root);
        int visited = 0;
        while (!pending.isEmpty() && visited < MAX_NODES) {
            AccessibilityNodeInfo node = pending.removeFirst();
            visited++;
            snapshot.nodeCount = visited;
            try {
                if (!node.isVisibleToUser()) {
                    continue;
                }
                boolean password = node.isPassword();
                boolean editable = node.isEditable();
                CharSequence textValue = password ? null : node.getText();
                CharSequence descriptionValue = password ? null : node.getContentDescription();
                String text = clean(textValue);
                String description = clean(descriptionValue);
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                int rootHeight = Math.max(0, rootBounds.bottom - rootBounds.top);
                if (editable && !password && (rootHeight == 0
                        || bounds.bottom >= rootBounds.top + rootHeight / 2)) {
                    snapshot.hasComposer = true;
                }
                // Group evidence must come from the fixed header region, not arbitrary chat
                // message bodies that happen to mention a group or a member count.
                if (bounds.top <= groupHeaderBottom
                        && (containsGroupMarker(text) || containsGroupMarker(description))) {
                    snapshot.groupMarker = true;
                }
                if (bounds.top <= groupHeaderBottom) {
                    String candidate = !text.isEmpty() ? text : description;
                    if (!candidate.isEmpty() && candidate.length() <= 80
                            && !isUiControl(candidate) && !isTimeLike(candidate)) {
                        if (snapshot.headerCandidates.length() < 240) {
                            if (snapshot.headerCandidates.length() > 0) {
                                snapshot.headerCandidates.append(" | ");
                            }
                            snapshot.headerCandidates.append(candidate);
                        }
                    }
                }

                if (editable && !password) {
                    snapshot.composerCount++;
                }
                if (!password && !editable && node.getChildCount() == 0) {
                    String value = !text.isEmpty() ? text : description;
                    if (isCandidate(value)) {
                        found.add(new PositionedText(bounds.top, bounds.left, value));
                    }
                }

                for (int i = 0; i < node.getChildCount() && visited + pending.size() < MAX_NODES; i++) {
                    AccessibilityNodeInfo child = node.getChild(i);
                    if (child != null) {
                        pending.addLast(child);
                    }
                }
            } finally {
                if (node != root) {
                    node.recycle();
                }
            }
        }
        while (!pending.isEmpty()) {
            AccessibilityNodeInfo left = pending.removeFirst();
            if (left != root) {
                left.recycle();
            }
        }
        Collections.sort(found, new Comparator<PositionedText>() {
            @Override
            public int compare(PositionedText a, PositionedText b) {
                if (a.top != b.top) {
                    return a.top < b.top ? -1 : 1;
                }
                return a.left < b.left ? -1 : (a.left == b.left ? 0 : 1);
            }
        });
        for (PositionedText item : found) {
            snapshot.fragments.add(item.text); // List intentionally preserves repeated identical messages.
            if (snapshot.conversationSignature.isEmpty()
                    && item.top <= signatureBottom
                    && !isUiControl(item.text) && !isTimeLike(item.text)
                    && !isSensitiveLike(item.text) && item.text.length() <= 100) {
                snapshot.conversationSignature = item.text;
            }
        }
        return snapshot;
    }

    // ------------------------------------------------------------------ sending

    private void scheduleTick(long delayMs) {
        if (tickScheduled && delayMs > 0L) {
            return;
        }
        handler.removeCallbacks(tickRunnable);
        tickScheduled = true;
        handler.postDelayed(tickRunnable, delayMs);
    }

    private void tickPending() {
        JSONObject outgoing = ObserverControl.getOutgoing(this);
        if (outgoing == null) {
            stage = 0;
            stageToken = "";
            return;
        }
        String token = outgoing.optString("token");
        String text = outgoing.optString("text");
        boolean confirmed = outgoing.optBoolean("confirmed", false);
        long queuedAt = outgoing.optLong("queued_at_ms", System.currentTimeMillis());

        if (!confirmed && !ObserverControl.isAutoSendEnabled(this)) {
            ObserverControl.failOutgoing(this, token, "自动发送已关闭，已取消待发回复");
            stage = 0;
            return;
        }
        if (!token.equals(stageToken)) {
            stageToken = token;
            stage = 0;
        }
        if (stage == 0) {
            String reason = ObserverControl.rateLimitReason(this, confirmed);
            if (reason != null) {
                ObserverControl.failOutgoing(this, token, reason);
                return;
            }
        }

        AccessibilityNodeInfo root = null;
        try {
            root = getSupportedWindowRoot();
            if (root == null || !isDouyinWindow(root)) {
                ObserverControl.setServiceState(this, true, "等待你回到抖音群聊页面以发送回复");
                scheduleTick(TICK_MS);
                return;
            }
            PageSnapshot page = collectVisibleText(root);
            if (!page.groupMarker || !page.hasComposer) {
                ObserverControl.setServiceState(this, true,
                        "等待进入抖音群聊页面以发送回复（无法确认当前是群聊）");
                scheduleTick(TICK_MS);
                return;
            }
            if (stage == 0) {
                typeReply(root, token, text, queuedAt);
            } else {
                tapSend(root, token, text);
            }
        } catch (RuntimeException exception) {
            ObserverControl.failOutgoing(this, token, "发送过程中发生异常，已取消本条回复");
            stage = 0;
        } finally {
            if (root != null) {
                root.recycle();
            }
        }
    }

    private void typeReply(AccessibilityNodeInfo root, String token, String text, long queuedAt) {
        AccessibilityNodeInfo composer = findNode(root, new NodeMatcher() {
            @Override
            public boolean matches(AccessibilityNodeInfo node) {
                return node.isEditable() && !node.isPassword();
            }
        });
        if (composer == null) {
            if (System.currentTimeMillis() - queuedAt > COMPOSER_WAIT_MS) {
                ObserverControl.failOutgoing(this, token, "找不到群聊输入框，未发送");
            } else {
                scheduleTick(TICK_MS);
            }
            return;
        }
        try {
            if (composerHasUserText(composer)) {
                ObserverControl.failOutgoing(this, token,
                        "输入框里已有内容，为避免覆盖你的文字，未发送");
                return;
            }
            Bundle arguments = new Bundle();
            arguments.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            boolean typed = composer.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
            if (!typed) {
                // Some custom inputs reject SET_TEXT; paste works there. The text is verified
                // before Send is tapped, so a failed paste can never send the wrong thing.
                typed = pasteFallback(composer, text);
            }
            if (!typed) {
                ObserverControl.failOutgoing(this, token,
                        "抖音输入框不接受自动填入文字，未发送");
                return;
            }
            stage = 1;
            stageStartedAt = System.currentTimeMillis();
            ObserverControl.setServiceState(this, true, "已填入回复，正在查找发送按钮");
            scheduleTick(TICK_MS);
        } finally {
            composer.recycle();
        }
    }

    private void tapSend(AccessibilityNodeInfo root, String token, String text) {
        boolean timedOut = System.currentTimeMillis() - stageStartedAt > SEND_BUTTON_WAIT_MS;

        AccessibilityNodeInfo composer = findNode(root, new NodeMatcher() {
            @Override
            public boolean matches(AccessibilityNodeInfo node) {
                return node.isEditable() && !node.isPassword();
            }
        });
        boolean textMatches = false;
        if (composer != null) {
            try {
                textMatches = ObserverControl.normalizeForCompare(clean(composer.getText()))
                        .equals(ObserverControl.normalizeForCompare(text));
            } finally {
                composer.recycle();
            }
        }
        if (!textMatches) {
            if (timedOut) {
                ObserverControl.failOutgoing(this, token,
                        "输入框内容与预期不一致，未点击发送（请检查输入框）");
                stage = 0;
            } else {
                scheduleTick(TICK_MS);
            }
            return;
        }

        AccessibilityNodeInfo send = findNode(root, new NodeMatcher() {
            @Override
            public boolean matches(AccessibilityNodeInfo node) {
                if (node.isEditable() || node.isPassword()) {
                    return false;
                }
                String label = clean(node.getText());
                if (label.isEmpty()) {
                    label = clean(node.getContentDescription());
                }
                return label.equals("发送") || label.equalsIgnoreCase("send");
            }
        });
        if (send == null) {
            if (timedOut) {
                ObserverControl.failOutgoing(this, token,
                        "找不到发送按钮；回复文字已留在输入框，请手动点发送");
                stage = 0;
            } else {
                scheduleTick(TICK_MS);
            }
            return;
        }
        try {
            if (clickNodeOrClickableParent(send)) {
                ObserverControl.recordSent(this, token, text);
                ObserverControl.setServiceState(this, true,
                        "已点击抖音发送按钮；平台最终送达状态无法由无障碍动作确认");
                stage = 0;
                stageToken = "";
            } else if (timedOut) {
                ObserverControl.failOutgoing(this, token,
                        "发送按钮点击失败；回复文字已留在输入框，请手动点发送");
                stage = 0;
            } else {
                scheduleTick(TICK_MS);
            }
        } finally {
            send.recycle();
        }
    }

    private boolean pasteFallback(AccessibilityNodeInfo composer, String text) {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard == null) {
                return false;
            }
            clipboard.setPrimaryClip(ClipData.newPlainText("xilian-reply", text));
            composer.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            return composer.performAction(AccessibilityNodeInfo.ACTION_PASTE);
        } catch (RuntimeException exception) {
            return false;
        }
    }

    private boolean composerHasUserText(AccessibilityNodeInfo composer) {
        CharSequence value = composer.getText();
        if (value == null || value.length() == 0) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 26 && composer.isShowingHintText()) {
            return false;
        }
        return !isComposerHint(clean(value));
    }

    /** Some apps expose the placeholder as real text; never mistake it for the user's draft. */
    private static boolean isComposerHint(String text) {
        String value = text.replace("…", "").replace("...", "").trim();
        return value.isEmpty() || value.equals("发消息") || value.equals("发送消息")
                || value.equals("输入消息") || value.equals("说点什么")
                || value.equals("发条消息") || value.equals("请输入消息")
                || value.equalsIgnoreCase("message") || value.equalsIgnoreCase("send a message");
    }

    private boolean clickNodeOrClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        int depth = 0;
        while (current != null && depth < 4) {
            if (current.isClickable() && current.isEnabled()) {
                boolean clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                if (current != node) {
                    current.recycle();
                }
                return clicked;
            }
            AccessibilityNodeInfo parent = current.getParent();
            if (current != node) {
                current.recycle();
            }
            current = parent;
            depth++;
        }
        if (current != null && current != node) {
            current.recycle();
        }
        return false;
    }

    private interface NodeMatcher {
        boolean matches(AccessibilityNodeInfo node);
    }

    /** Lowest visible matching node on screen. The caller must recycle the returned node. */
    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo root, NodeMatcher matcher) {
        AccessibilityNodeInfo best = null;
        int bestTop = Integer.MIN_VALUE;
        Deque<AccessibilityNodeInfo> pending = new ArrayDeque<>();
        pending.addLast(root);
        int visited = 0;
        while (!pending.isEmpty() && visited < MAX_NODES) {
            AccessibilityNodeInfo node = pending.removeFirst();
            visited++;
            boolean keep = false;
            try {
                if (!node.isVisibleToUser()) {
                    continue;
                }
                if (matcher.matches(node)) {
                    Rect bounds = new Rect();
                    node.getBoundsInScreen(bounds);
                    if (bounds.top >= bestTop) {
                        if (best != null && best != root) {
                            best.recycle();
                        }
                        best = node;
                        bestTop = bounds.top;
                        keep = true;
                    }
                }
                for (int i = 0; i < node.getChildCount() && visited + pending.size() < MAX_NODES; i++) {
                    AccessibilityNodeInfo child = node.getChild(i);
                    if (child != null) {
                        pending.addLast(child);
                    }
                }
            } finally {
                if (!keep && node != root) {
                    node.recycle();
                }
            }
        }
        while (!pending.isEmpty()) {
            AccessibilityNodeInfo left = pending.removeFirst();
            if (left != root) {
                left.recycle();
            }
        }
        if (best == root) {
            // Never hand the caller the window root; it is recycled by the caller of this class.
            return null;
        }
        return best;
    }

    // ------------------------------------------------------------------ text helpers

    private static String clean(CharSequence value) {
        if (value == null) {
            return "";
        }
        String text = value.toString().replace('\u0000', ' ').trim();
        return text.replaceAll("\\s+", " ");
    }

    private static boolean containsGroupMarker(String text) {
        if (text == null || text.isEmpty()) {
            return false;
        }
        String value = text.toLowerCase(Locale.ROOT);
        // Chat headers vary by app version: some expose only a group name and member count,
        // rather than the literal label “群聊”. Do not require that exact UI string.
        return text.contains("群聊") || text.contains("群组") || text.contains("多人聊天")
                || text.contains("群成员") || text.contains("群设置")
                || GROUP_MEMBER_COUNT.matcher(text).matches()
                || value.contains("group chat") || value.contains("group members");
    }

    private static boolean isCandidate(String text) {
        return text != null && !text.isEmpty() && text.length() <= 800
                && !isUiControl(text) && !isSensitiveLike(text)
                && !isInternalDiagnosticText(text);
    }

    /** Defense in depth: never feed obvious app diagnostics/status text into chat memory. */
    private static boolean isInternalDiagnosticText(String text) {
        String value = text.toLowerCase(Locale.ROOT);
        return value.contains("诊断：待处理") || value.contains("诊斷：待處理")
                || value.contains("原生自动发送开关")
                || value.contains("本机观察历史") || value.contains("可见文字观察记录")
                || value.contains("已排入发送队列") || value.contains("模型请求失败")
                || value.contains("连接测试失败") || value.contains("openrouter api")
                || value.contains("回复：自动发送") || value.contains("回复：仅草稿")
                || value.contains("回复：关闭") || value.contains("昔涟思考中")
                || value.contains("昔涟（草稿）") || value.contains("昔涟（自动发送中）")
                || value.contains("昔涟 ai ·");
    }

    private static boolean isTimeLike(String text) {
        return TIME_LIKE.matcher(text.trim()).matches();
    }

    private static boolean isUiControl(String text) {
        String value = text.trim();
        return value.isEmpty() || value.equals("群聊") || value.equals("群聊设置")
                || value.equals("群聊成员") || value.equals("发送")
                || value.equals("返回") || value.equals("更多")
                || value.equals("复制") || value.equals("转发")
                || value.equals("评论") || value.equals("点赞")
                || value.equals("分享") || value.equals("输入消息")
                || value.equals("说点什么") || value.equals("聊天");
    }

    private static boolean isSensitiveLike(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        return lower.contains("cookie") || lower.contains("access_token")
                || lower.contains("authorization") || lower.contains("bearer ")
                || lower.contains("password") || lower.contains("passwd")
                || lower.contains("token") || text.contains("密码")
                || text.contains("口令") || text.contains("验证码")
                || text.contains("登录凭证");
    }

    private static final class PositionedText {
        final int top;
        final int left;
        final String text;

        PositionedText(int top, int left, String text) {
            this.top = top;
            this.left = left;
            this.text = text;
        }
    }

    private static final class PageSnapshot {
        boolean groupMarker;
        boolean hasComposer;
        StringBuilder headerCandidates = new StringBuilder();
        int nodeCount;
        int composerCount;
        String conversationSignature = "";
        final List<String> fragments = new ArrayList<>();
    }
}
