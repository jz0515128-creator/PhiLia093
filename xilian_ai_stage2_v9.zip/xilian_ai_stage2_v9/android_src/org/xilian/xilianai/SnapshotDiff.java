package org.xilian.xilianai;

import java.util.ArrayList;
import java.util.List;

/**
 * Pure snapshot-diff logic so its key cases can be tested without an Android device.
 * The input order is top-to-bottom visible text. Repeated equal strings are meaningful entries.
 */
final class SnapshotDiff {
    private static final int MAX_FRESH_PER_PASS = 12;
    // Douyin keeps a fixed footer under the message list (quick-reply chips, voice/emoji/more
    // buttons). New messages appear BEFORE that footer, so they are an insertion, not an append.
    private static final int MIN_STABLE_FOOTER = 3;

    private SnapshotDiff() {}

    static List<String> computeFresh(List<String> previous, List<String> current) {
        List<String> fresh = new ArrayList<>();
        if (previous == null || previous.isEmpty() || current == null || current.isEmpty()) {
            return fresh;
        }

        if (isExactPrefix(previous, current)) {
            for (int i = previous.size(); i < current.size(); i++) {
                fresh.add(current.get(i));
            }
            return limitFresh(fresh);
        }

        // Some views replace the last partially-rendered fragment while appending a new one.
        // Compare the stable prefix, then verify that the old tail did not merely shift down
        // (which would indicate an insertion/reorder rather than a bottom append).
        if (current.size() > previous.size()) {
            boolean stablePrefix = true;
            int prefixLength = Math.max(0, previous.size() - 1);
            for (int i = 0; i < prefixLength; i++) {
                if (!previous.get(i).equals(current.get(i))) {
                    stablePrefix = false;
                    break;
                }
            }
            if (stablePrefix) {
                boolean oldTailShifted = false;
                String oldTail = previous.get(previous.size() - 1);
                for (int i = previous.size() - 1; i < current.size(); i++) {
                    if (oldTail.equals(current.get(i))) {
                        oldTailShifted = true;
                        break;
                    }
                }
                if (!oldTailShifted) {
                    for (int i = previous.size(); i < current.size(); i++) {
                        fresh.add(current.get(i));
                    }
                    return limitFresh(fresh);
                }
            }
        }

        // V9: new message(s) inserted just above a stable footer (see MIN_STABLE_FOOTER).
        List<String> beforeFooter = insertedBeforeStableFooter(previous, current);
        if (beforeFooter != null) {
            return limitFresh(beforeFooter);
        }

        // Scrolling: the previous viewport's tail becomes the current viewport's head.
        int overlap = findOverlap(previous, current);
        if (overlap > 0) {
            for (int i = overlap; i < current.size(); i++) {
                fresh.add(current.get(i));
            }
            return limitFresh(fresh);
        }
        // No trustworthy overlap: conservatively emit nothing and let the caller reset baseline.
        return fresh;
    }

    /**
     * Returns the inserted fragments when current == prefix + inserted + footer and previous ==
     * prefix + (at most one edited fragment) + footer, where footer is at least
     * MIN_STABLE_FOOTER long and prefix is non-empty. Returns null when this shape does not
     * apply. Insertions at the head (history loading) have an empty prefix and are rejected;
     * short tails (a single shifted fragment) are rejected by MIN_STABLE_FOOTER.
     */
    static List<String> insertedBeforeStableFooter(List<String> previous, List<String> current) {
        if (current.size() <= previous.size()) {
            return null;
        }
        int prefix = 0;
        while (prefix < previous.size() && previous.get(prefix).equals(current.get(prefix))) {
            prefix++;
        }
        int suffix = 0;
        while (suffix < previous.size() - prefix
                && previous.get(previous.size() - 1 - suffix)
                        .equals(current.get(current.size() - 1 - suffix))) {
            suffix++;
        }
        int oldMiddle = previous.size() - prefix - suffix;
        if (prefix < 1 || suffix < MIN_STABLE_FOOTER || oldMiddle < 0 || oldMiddle > 1) {
            return null;
        }
        int from = prefix + oldMiddle;
        int to = current.size() - suffix;
        if (to <= from) {
            return null;
        }
        return new ArrayList<>(current.subList(from, to));
    }

    static int findOverlap(List<String> previous, List<String> current) {
        if (previous == null || previous.isEmpty() || current == null || current.isEmpty()) {
            return 0;
        }
        for (int start = 0; start < previous.size(); start++) {
            int overlap = previous.size() - start;
            if (overlap > current.size()) {
                continue;
            }
            boolean match = true;
            for (int i = 0; i < overlap; i++) {
                if (!previous.get(start + i).equals(current.get(i))) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return overlap;
            }
        }
        return 0;
    }

    static boolean isExactPrefix(List<String> previous, List<String> current) {
        if (previous == null || current == null || previous.size() > current.size()) {
            return false;
        }
        for (int i = 0; i < previous.size(); i++) {
            if (!previous.get(i).equals(current.get(i))) {
                return false;
            }
        }
        return true;
    }

    private static List<String> limitFresh(List<String> fresh) {
        if (fresh.size() > MAX_FRESH_PER_PASS) {
            return new ArrayList<>(fresh.subList(fresh.size() - MAX_FRESH_PER_PASS, fresh.size()));
        }
        return fresh;
    }
}
