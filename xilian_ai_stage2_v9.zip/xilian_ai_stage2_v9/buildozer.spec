[app]
title = 昔涟AI
package.name = xilianai
package.domain = org.xilian
source.dir = .
source.include_exts = py,png,jpg,kv,json
source.exclude_patterns = p4a_hook.py,tests/*,tools/*
version = 2.3
requirements = python3,kivy==2.3.0,requests,urllib3,chardet,idna,certifi,sqlite3
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 33
android.minapi = 24
android.archs = arm64-v8a
android.accept_sdk_license = True
android.add_src = android_src
android.add_resources = android_res
p4a.hook = p4a_hook.py
p4a.branch = v2024.01.21

[buildozer]
log_level = 2
warn_on_root = 1
