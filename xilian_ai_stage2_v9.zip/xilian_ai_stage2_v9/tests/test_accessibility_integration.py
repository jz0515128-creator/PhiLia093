import re
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"


class AccessibilityIntegrationTests(unittest.TestCase):
    def test_service_manifest_requires_system_accessibility_binding(self):
        fragment = (ROOT / "android_manifest_service.xml").read_text(encoding="utf-8")
        wrapped = (
            '<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
            f"<application>{fragment}</application></manifest>"
        )
        root = ET.fromstring(wrapped)
        service = root.find("application/service")
        self.assertIsNotNone(service)
        self.assertEqual(
            service.get(ANDROID_NS + "permission"),
            "android.permission.BIND_ACCESSIBILITY_SERVICE",
        )
        self.assertEqual(service.get(ANDROID_NS + "exported"), "true")
        actions = [node.get(ANDROID_NS + "name") for node in service.findall("intent-filter/action")]
        self.assertIn("android.accessibilityservice.AccessibilityService", actions)
        metadata = service.find("meta-data")
        self.assertEqual(metadata.get(ANDROID_NS + "resource"), "@xml/xilian_accessibility_service")

    def test_service_is_restricted_to_douyin_and_visible_nodes(self):
        config = ET.parse(ROOT / "android_res/xml/xilian_accessibility_service.xml").getroot()
        self.assertEqual(config.get(ANDROID_NS + "packageNames"), "com.ss.android.ugc.aweme,com.zhiliaoapp.musically,com.ss.android.ugc.trill")
        self.assertEqual(config.get(ANDROID_NS + "canRetrieveWindowContent"), "true")
        self.assertIn("typeWindowContentChanged", config.get(ANDROID_NS + "accessibilityEventTypes"))
        self.assertIn("typeViewScrolled", config.get(ANDROID_NS + "accessibilityEventTypes"))
        self.assertIn("flagRetrieveInteractiveWindows", config.get(ANDROID_NS + "accessibilityFlags"))
        self.assertIsNone(config.get(ANDROID_NS + "canPerformGestures"))

    def test_service_keeps_chat_signals_and_privacy_guards(self):
        source = (ROOT / "android_src/org/xilian/xilianai/DouyinAccessibilityService.java").read_text(
            encoding="utf-8"
        )
        self.assertIn('"com.ss.android.ugc.aweme"', source)
        self.assertIn("!page.groupMarker || !page.hasComposer", source)
        self.assertIn("scheduleObservationPoll(OBSERVATION_POLL_MS)", source)
        self.assertIn("requestObservationPoll()", source)
        self.assertIn("会继续每秒检查", source)
        self.assertNotIn("if (consecutiveWindowMisses <= 3)", source)
        self.assertIn("getSupportedWindowRoot()", source)
        main_source = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertIn("requestObservationPoll()", main_source)
        self.assertIn("lastSnapshots.clear()", source)
        self.assertIn("getBaselineResetGeneration(this)", source)
        self.assertIn("观察已暂停；未读取或保存抖音文字", source)
        self.assertIn("平台最终送达状态无法由无障碍动作确认", source)
        self.assertIn("conversationSignature", source)
        self.assertIn("groupHeaderBottom", source)
        self.assertIn("signatureBottom", source)
        self.assertIn("rootHeightForHeader * 35 / 100", source)

    def test_v8_window_fallback_and_group_header_marker(self):
        source = (ROOT / "android_src/org/xilian/xilianai/DouyinAccessibilityService.java").read_text(
            encoding="utf-8"
        )
        # 活动窗口取不到时，改用事件源节点向上找根，并把窗口诊断写进状态行
        self.assertIn("rootFromEvent(event)", source)
        self.assertIn("lastWindowDiagnostic", source)
        self.assertIn("诊断：", source)
        # 真机群聊页头副标题形如「13名群友在线」
        self.assertIn("群友在线", source)
        self.assertIn("GROUP_FRIENDS_ONLINE", source)
        # 仍只接受受支持的抖音/TikTok 包名，不扫描其他应用
        self.assertIn("isDouyinWindow(candidate)", source)
        self.assertIn("继续轮询，未触发回复", source)
        self.assertIn("page.headerCandidates", source)
        self.assertIn("pending.addLast(child)", source)
        self.assertIn("pending.removeFirst()", source)
        self.assertIn("node.isPassword()", source)
        self.assertIn('text.contains("密码")', source)
        self.assertIn('text.contains("验证码")', source)
        self.assertIn("isInternalDiagnosticText(text)", source)
        self.assertIn("可见文字观察记录", source)
        self.assertIn('lower.contains("cookie")', source)
        self.assertIn("0.45d", source)
        self.assertIn("PARTIAL_STATUS", source)
        # Gestures stay forbidden: the service may only type into the composer and tap Send.
        self.assertIsNone(re.search(r"dispatchGesture|GestureDescription|performGlobalAction", source))

    def test_observation_diff_detects_appended_chat_messages(self):
        source = (ROOT / "android_src/org/xilian/xilianai/DouyinAccessibilityService.java").read_text(
            encoding="utf-8"
        )
        # Regression logic lives in a pure-Java helper with executable tests.
        self.assertIn("SnapshotDiff.computeFresh(previous, current)", source)
        helper = (ROOT / "android_src/org/xilian/xilianai/SnapshotDiff.java").read_text(encoding="utf-8")
        self.assertIn("isExactPrefix(previous, current)", helper)
        self.assertIn("previous.size() - 1", helper)
        self.assertIn("Repeated equal strings are meaningful entries", helper)
        self.assertIn("findOverlap(previous, current)", helper)

    def test_sending_is_guarded(self):
        service = (ROOT / "android_src/org/xilian/xilianai/DouyinAccessibilityService.java").read_text(
            encoding="utf-8"
        )
        control = (ROOT / "android_src/org/xilian/xilianai/ObserverControl.java").read_text(
            encoding="utf-8"
        )
        # Only a confirmed reply, or automatic mode that the user switched on.
        self.assertIn("!confirmed && !ObserverControl.isAutoSendEnabled(this)", service)
        self.assertIn("!userConfirmed && !isAutoSendEnabled(context)", control)
        # Never overwrite the user's own draft and verify the composer before tapping Send.
        self.assertIn("composerHasUserText(composer)", service)
        self.assertIn("textMatches", service)
        # The paste fallback is only acceptable because the typed text is verified before Send.
        self.assertIn("pasteFallback(composer, text)", service)
        # Hard limits and expiry live in the native layer, not only in the UI.
        for name in ("AUTO_MIN_INTERVAL_MS", "MANUAL_MIN_INTERVAL_MS",
                     "MAX_SENDS_PER_HOUR", "OUTGOING_TTL_MS", "MAX_REPLY_CHARS"):
            self.assertIn(name, control)
        # Own messages must not be answered again.
        self.assertIn("isOwnRecentText", service)
        self.assertIn("自动发送已关闭；待发回复已取消", control)
        main_source = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertIn('controller.cancelOutgoing(activity, "回覆模式已关闭；待发回复已取消")', main_source)
        control_source = (ROOT / "android_src/org/xilian/xilianai/ObserverControl.java").read_text(encoding="utf-8")
        self.assertIn("KEY_BASELINE_RESET_GENERATION", control_source)
        self.assertIn("无法确认平台最终送达状态", control)
        # Auto-send can only be switched on while the system service is enabled.
        self.assertIn("enabled && !isAccessibilityServiceEnabled(context)", control)
        # Gestures flag stays off in the service config.
        config = ET.parse(ROOT / "android_res/xml/xilian_accessibility_service.xml").getroot()
        self.assertIsNone(config.get(ANDROID_NS + "canPerformGestures"))

    def test_accessibility_description_discloses_sending(self):
        strings = (ROOT / "android_res/values/xilian_observer_strings.xml").read_text(
            encoding="utf-8"
        )
        self.assertIn("发送", strings)
        self.assertNotIn("不会点击或发送消息", strings)

    def test_buildozer_includes_native_source_resources_and_manifest_fragment(self):
        spec = (ROOT / "buildozer.spec").read_text(encoding="utf-8")
        self.assertIn("android.add_src = android_src", spec)
        self.assertIn("android.add_resources = android_res", spec)
        self.assertIn("p4a.hook = p4a_hook.py", spec)
        # extra_manifest_xml is written under <manifest>; wrapping a service in it created a
        # second <application> that Android ignores, so it must not be used for the service.
        self.assertNotIn("android.extra_manifest_xml", spec)
        self.assertTrue((ROOT / "android_manifest_service.xml").is_file())
        self.assertFalse((ROOT / "android_manifest_components.xml").exists())


if __name__ == "__main__":
    unittest.main()
