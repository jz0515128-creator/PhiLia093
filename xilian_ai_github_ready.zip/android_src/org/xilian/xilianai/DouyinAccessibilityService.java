package org.xilian.xilianai;

import android.accessibilityservice.AccessibilityService;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Observes visible text of the official Douyin app and, only after the user has asked for it,
 * types one generated reply into the group-chat composer and taps Send.
 *
 * Sending rules (all enforced here or in ObserverControl, not just in the UI):
 *  - only the Douyin package, only a page that looks like a group chat with an input box;
 *  - only a reply the user confirmed, or any reply while the user has switched automatic mode on;
 *  - never over text the user already typed; the composer must contain exactly our text before Send;
 *  - cooldown and hourly cap; pending replies expire after two minutes;
 *  - no gestures, no navigation, no reading of password fields.
 */
public class DouyinAccessibilityService extends AccessibilityService {
    // Mainland Douyin and common international TikTok package IDs.
    // Accessibility events are still limited to these apps by the service XML.
    private static final Set<String> SUPPORTED_CHAT_PACKAGES = new LinkedHashSet<>(Arrays.asList(
            "com.ss.android.ugc.aweme", // Douyin (mainland China)
            "com.zhiliaoapp.musically", // TikTok international
            "com.ss.android.ugc.trill"  // TikTok regional builds
    ));
    private static final int MAX_NODES = 400;
    private static final int MAX_FRESH_PER_EVENT = 5;
    private static final int MAX_SNAPSHOTS = 10;
    private static final long TICK_MS = 700L;
    private static final long COMPOSER_WAIT_MS = 20_000L;
    private static final long SEND_BUTTON_WAIT_MS = 6_000L;
    private static final String PARTIAL_STATUS =
            "可见文字片段（不保证消息完整，发送者可能无法识别）";
    private static final Pattern GROUP_MEMBER_COUNT = Pattern.compile(".*(?:等\\s*)?\\d+\\s*人.*");
    private static final Pattern TIME_LIKE = Pattern.compile(
            "^(?:刚刚|\\d+\\s*(?:秒|分钟|小时|天)前"
                    + "|(?:(?:今天|昨天|前天|凌晨|上午|中午|下午|晚上|星期[一二三四五六日天]|周[一二三四五六日天]"
                    + "|\\d{1,4}[-/年.]\\d{1,2}(?:[-/月.]\\d{0,2}日?)?)\\s*)?"
                    + "\\d{1,2}[:：]\\d{2}(?:[:：]\\d{2})?)$");

    private static final String SESSION_ID = "douyin-chat";

    private static volatile DouyinAccessibilityService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, List<String>> lastSnapshots = new HashMap<>();
    private final Runnable tickRunnable = new Runnable() {
        @Override
        public void run() {
            tickScheduled = false;
            tickPending();
        }
    };

    private boolean tickScheduled;
    private String stageToken = "";
    private int stage; // 0 = nothing typed yet, 1 = our text typed, waiting to tap Send
    private long stageStartedAt;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        String status = ObserverControl.isObservingEnabled(this)
                ? "系统服务已连接；正在等待抖音群聊页面"
                : "系统服务已连接；App 内观察开关目前暂停";
        ObserverControl.setServiceState(this, true, status);
        if (ObserverControl.hasOutgoing(this)) {
            scheduleTick(TICK_MS);
        }
    }

    /** Called from Python right after a reply is queued so sending starts without waiting for an event. */
    public static void requestTick() {
        final DouyinAccessibilityService service = instance;
        if (service != null) {
            service.handler.post(new Runnable() {
                @Override
                public void run() {
                    service.scheduleTick(0L);
                }
            });
        }
    }

    @Override
    public void onInterrupt() {
        ObserverControl.setServiceState(this, false,
                "Android 系统中断了观察服务；请检查无障碍设置后重新进入抖音");
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        handler.removeCallbacks(tickRunnable);
        tickScheduled = false;
        ObserverControl.clearOutgoing(this);
        instance = null;
        ObserverControl.setServiceState(this, false,
                "系统辅助功能服务已断开；没有后台读取");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tickRunnable);
        instance = null;
        ObserverControl.setServiceState(this, false,
                "系统辅助功能服务已停止；没有后台读取");
        super.onDestroy();
    }

    // ------------------------------------------------------------------ observing

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) {
            return;
        }
        if (!isSupportedChatPackage(event.getPackageName().toString())) {
            return;
        }
        if (ObserverControl.hasOutgoing(this)) {
            scheduleTick(TICK_MS);
        }
        if (!ObserverControl.isObservingEnabled(this)) {
            if (!ObserverControl.hasOutgoing(this)) {
                ObserverControl.setServiceState(this, true, "观察已暂停；未读取或保存抖音文字");
            }
            return;
        }

        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root == null) {
                ObserverControl.setServiceState(this, true,
                        "抖音页面节点不可读取；本次未保存任何文字");
                return;
            }
            if (!isDouyinWindow(root)) {
                return;
            }

            PageSnapshot page = collectVisibleText(root);
            if (!page.groupMarker || !page.hasComposer) {
                ObserverControl.setServiceState(this, true,
                        "当前页面未通过群聊识别：群标记=" + page.groupMarker
                                + "，输入框=" + page.hasComposer + "；未保存页面文字");
                return;
            }

            List<String> visible = new ArrayList<>();
            for (String fragment : page.fragments) {
                if (isSensitiveLike(fragment) || isUiControl(fragment) || isTimeLike(fragment)
                        || ObserverControl.isOwnRecentText(this, fragment)) {
                    continue;
                }
                visible.add(fragment);
            }
            if (visible.isEmpty()) {
                ObserverControl.setServiceState(this, true,
                        "疑似抖音群聊，但当前没有可读取的消息文字；未保存");
                return;
            }

            String sessionId = SESSION_ID;
            long now = System.currentTimeMillis();
            List<String> previous = lastSnapshots.get(sessionId);
            if (lastSnapshots.size() >= MAX_SNAPSHOTS && previous == null) {
                lastSnapshots.clear();
            }
            lastSnapshots.put(sessionId, new ArrayList<>(visible));

            int recorded = 0;
            if (previous == null) {
                // First look at this chat window: keep a baseline for display, never treat as new.
                for (String fragment : visible) {
                    ObserverControl.appendObservation(this, sessionId, "", fragment, now,
                            0.45d, PARTIAL_STATUS, false);
                    recorded++;
                }
                ObserverControl.setServiceState(this, true,
                        "疑似抖音群聊：已读取当前页面作为基线（" + recorded + " 条），之后只处理新出现的文字");
                return;
            }

            List<String> fresh = computeFresh(previous, visible);
            for (String fragment : fresh) {
                ObserverControl.appendObservation(this, sessionId, "", fragment, now,
                        0.45d, PARTIAL_STATUS, true);
                recorded++;
            }
            if (recorded > 0) {
                ObserverControl.setServiceState(this, true,
                        "疑似抖音群聊：发现 " + recorded + " 条新的可见文字；内容可能不完整");
            } else if (findOverlap(previous, visible) == 0) {
                ObserverControl.setServiceState(this, true,
                        "疑似抖音群聊：页面内容变化较大，无法确认哪条是新消息；已重置基线");
            } else {
                ObserverControl.setServiceState(this, true,
                        "疑似抖音群聊：暂无新消息（当前读到 " + visible.size() + " 行）");
            }
        } catch (RuntimeException exception) {
            // Deliberately omit exception text and screen content from logs/status.
            ObserverControl.setServiceState(this, true,
                    "读取抖音可见文字时发生异常；已恢复，未确认本次内容");
        } finally {
            if (root != null) {
                root.recycle();
            }
        }
    }

    /**
     * New messages appear below the previous ones. A fragment is "new" only if it follows a run
     * of fragments that was already on screen. If there is no overlap at all (scrolled, page
     * changed) nothing is treated as new, so old history is never answered.
     */
    static List<String> computeFresh(List<String> previous, List<String> current) {
        List<String> fresh = new ArrayList<>();
        int overlap = findOverlap(previous, current);
        if (overlap == 0) {
            return fresh;
        }
        for (int i = overlap; i < current.size(); i++) {
            fresh.add(current.get(i));
        }
        if (fresh.size() > MAX_FRESH_PER_EVENT) {
            return new ArrayList<>(fresh.subList(fresh.size() - MAX_FRESH_PER_EVENT, fresh.size()));
        }
        return fresh;
    }

    /** Length of the longest tail of previous that is also the head of current; 0 if none. */
    static int findOverlap(List<String> previous, List<String> current) {
        if (previous == null || previous.isEmpty() || current == null || current.isEmpty()) {
            return 0;
        }
        int prevSize = previous.size();
        for (int start = 0; start < prevSize; start++) {
            int overlap = prevSize - start;
            if (overlap > current.size()) {
                continue;
            }
            boolean match = true;
            for (int i = 0; i < overlap; i++) {
                if (!previous.get(start + i).equals(current.get(i))) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return overlap;
            }
        }
        return 0;
    }

    private static boolean isSupportedChatPackage(String packageName) {
        return packageName != null && SUPPORTED_CHAT_PACKAGES.contains(packageName);
    }

    private boolean isDouyinWindow(AccessibilityNodeInfo root) {
        CharSequence name = root.getPackageName();
        return name != null && isSupportedChatPackage(name.toString());
    }

    private PageSnapshot collectVisibleText(AccessibilityNodeInfo root) {
        PageSnapshot snapshot = new PageSnapshot();
        List<PositionedText> found = new ArrayList<>();
        Deque<AccessibilityNodeInfo> pending = new ArrayDeque<>();
        pending.push(root);
        int visited = 0;
        while (!pending.isEmpty() && visited < MAX_NODES) {
            AccessibilityNodeInfo node = pending.pop();
            visited++;
            try {
                if (!node.isVisibleToUser()) {
                    continue;
                }
                boolean password = node.isPassword();
                boolean editable = node.isEditable();
                if (editable) {
                    snapshot.hasComposer = true;
                }
                CharSequence textValue = password ? null : node.getText();
                CharSequence descriptionValue = password ? null : node.getContentDescription();
                String text = clean(textValue);
                String description = clean(descriptionValue);
                if (containsGroupMarker(text) || containsGroupMarker(description)) {
                    snapshot.groupMarker = true;
                }

                if (!password && !editable && node.getChildCount() == 0) {
                    String value = !text.isEmpty() ? text : description;
                    if (isCandidate(value)) {
                        Rect bounds = new Rect();
                        node.getBoundsInScreen(bounds);
                        found.add(new PositionedText(bounds.top, bounds.left, value));
                    }
                }

                for (int i = 0; i < node.getChildCount() && visited + pending.size() < MAX_NODES; i++) {
                    AccessibilityNodeInfo child = node.getChild(i);
                    if (child != null) {
                        pending.push(child);
                    }
                }
            } finally {
                if (node != root) {
                    node.recycle();
                }
            }
        }
        while (!pending.isEmpty()) {
            AccessibilityNodeInfo left = pending.pop();
            if (left != root) {
                left.recycle();
            }
        }
        Collections.sort(found, new Comparator<PositionedText>() {
            @Override
            public int compare(PositionedText a, PositionedText b) {
                if (a.top != b.top) {
                    return a.top < b.top ? -1 : 1;
                }
                return a.left < b.left ? -1 : (a.left == b.left ? 0 : 1);
            }
        });
        for (PositionedText item : found) {
            snapshot.fragments.add(item.text);
        }
        return snapshot;
    }

    // ------------------------------------------------------------------ sending

    private void scheduleTick(long delayMs) {
        if (tickScheduled && delayMs > 0L) {
            return;
        }
        handler.removeCallbacks(tickRunnable);
        tickScheduled = true;
        handler.postDelayed(tickRunnable, delayMs);
    }

    private void tickPending() {
        JSONObject outgoing = ObserverControl.getOutgoing(this);
        if (outgoing == null) {
            stage = 0;
            stageToken = "";
            return;
        }
        String token = outgoing.optString("token");
        String text = outgoing.optString("text");
        boolean confirmed = outgoing.optBoolean("confirmed", false);
        long queuedAt = outgoing.optLong("queued_at_ms", System.currentTimeMillis());

        if (!confirmed && !ObserverControl.isAutoSendEnabled(this)) {
            ObserverControl.failOutgoing(this, token, "自动发送已关闭，已取消待发回复");
            stage = 0;
            return;
        }
        if (!token.equals(stageToken)) {
            stageToken = token;
            stage = 0;
        }
        if (stage == 0) {
            String reason = ObserverControl.rateLimitReason(this, confirmed);
            if (reason != null) {
                ObserverControl.failOutgoing(this, token, reason);
                return;
            }
        }

        AccessibilityNodeInfo root = null;
        try {
            root = getRootInActiveWindow();
            if (root == null || !isDouyinWindow(root)) {
                ObserverControl.setServiceState(this, true, "等待你回到抖音群聊页面以发送回复");
                scheduleTick(TICK_MS);
                return;
            }
            PageSnapshot page = collectVisibleText(root);
            if (!page.groupMarker || !page.hasComposer) {
                ObserverControl.setServiceState(this, true,
                        "等待进入抖音群聊页面以发送回复（无法确认当前是群聊）");
                scheduleTick(TICK_MS);
                return;
            }
            if (stage == 0) {
                typeReply(root, token, text, queuedAt);
            } else {
                tapSend(root, token, text);
            }
        } catch (RuntimeException exception) {
            ObserverControl.failOutgoing(this, token, "发送过程中发生异常，已取消本条回复");
            stage = 0;
        } finally {
            if (root != null) {
                root.recycle();
            }
        }
    }

    private void typeReply(AccessibilityNodeInfo root, String token, String text, long queuedAt) {
        AccessibilityNodeInfo composer = findNode(root, new NodeMatcher() {
            @Override
            public boolean matches(AccessibilityNodeInfo node) {
                return node.isEditable() && !node.isPassword();
            }
        });
        if (composer == null) {
            if (System.currentTimeMillis() - queuedAt > COMPOSER_WAIT_MS) {
                ObserverControl.failOutgoing(this, token, "找不到群聊输入框，未发送");
            } else {
                scheduleTick(TICK_MS);
            }
            return;
        }
        try {
            if (composerHasUserText(composer)) {
                ObserverControl.failOutgoing(this, token,
                        "输入框里已有内容，为避免覆盖你的文字，未发送");
                return;
            }
            Bundle arguments = new Bundle();
            arguments.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            boolean typed = composer.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);
            if (!typed) {
                // Some custom inputs reject SET_TEXT; paste works there. The text is verified
                // before Send is tapped, so a failed paste can never send the wrong thing.
                typed = pasteFallback(composer, text);
            }
            if (!typed) {
                ObserverControl.failOutgoing(this, token,
                        "抖音输入框不接受自动填入文字，未发送");
                return;
            }
            stage = 1;
            stageStartedAt = System.currentTimeMillis();
            ObserverControl.setServiceState(this, true, "已填入回复，正在查找发送按钮");
            scheduleTick(TICK_MS);
        } finally {
            composer.recycle();
        }
    }

    private void tapSend(AccessibilityNodeInfo root, String token, String text) {
        boolean timedOut = System.currentTimeMillis() - stageStartedAt > SEND_BUTTON_WAIT_MS;

        AccessibilityNodeInfo composer = findNode(root, new NodeMatcher() {
            @Override
            public boolean matches(AccessibilityNodeInfo node) {
                return node.isEditable() && !node.isPassword();
            }
        });
        boolean textMatches = false;
        if (composer != null) {
            try {
                textMatches = ObserverControl.normalizeForCompare(clean(composer.getText()))
                        .equals(ObserverControl.normalizeForCompare(text));
            } finally {
                composer.recycle();
            }
        }
        if (!textMatches) {
            if (timedOut) {
                ObserverControl.failOutgoing(this, token,
                        "输入框内容与预期不一致，未点击发送（请检查输入框）");
                stage = 0;
            } else {
                scheduleTick(TICK_MS);
            }
            return;
        }

        AccessibilityNodeInfo send = findNode(root, new NodeMatcher() {
            @Override
            public boolean matches(AccessibilityNodeInfo node) {
                if (node.isEditable() || node.isPassword()) {
                    return false;
                }
                String label = clean(node.getText());
                if (label.isEmpty()) {
                    label = clean(node.getContentDescription());
                }
                return label.equals("发送") || label.equalsIgnoreCase("send");
            }
        });
        if (send == null) {
            if (timedOut) {
                ObserverControl.failOutgoing(this, token,
                        "找不到发送按钮；回复文字已留在输入框，请手动点发送");
                stage = 0;
            } else {
                scheduleTick(TICK_MS);
            }
            return;
        }
        try {
            if (clickNodeOrClickableParent(send)) {
                ObserverControl.recordSent(this, token, text);
                ObserverControl.setServiceState(this, true, "已发送一条回复到抖音群聊");
                stage = 0;
                stageToken = "";
            } else if (timedOut) {
                ObserverControl.failOutgoing(this, token,
                        "发送按钮点击失败；回复文字已留在输入框，请手动点发送");
                stage = 0;
            } else {
                scheduleTick(TICK_MS);
            }
        } finally {
            send.recycle();
        }
    }

    private boolean pasteFallback(AccessibilityNodeInfo composer, String text) {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard == null) {
                return false;
            }
            clipboard.setPrimaryClip(ClipData.newPlainText("xilian-reply", text));
            composer.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
            return composer.performAction(AccessibilityNodeInfo.ACTION_PASTE);
        } catch (RuntimeException exception) {
            return false;
        }
    }

    private boolean composerHasUserText(AccessibilityNodeInfo composer) {
        CharSequence value = composer.getText();
        if (value == null || value.length() == 0) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 26 && composer.isShowingHintText()) {
            return false;
        }
        return !isComposerHint(clean(value));
    }

    /** Some apps expose the placeholder as real text; never mistake it for the user's draft. */
    private static boolean isComposerHint(String text) {
        String value = text.replace("…", "").replace("...", "").trim();
        return value.isEmpty() || value.equals("发消息") || value.equals("发送消息")
                || value.equals("输入消息") || value.equals("说点什么")
                || value.equals("发条消息") || value.equals("请输入消息")
                || value.equalsIgnoreCase("message") || value.equalsIgnoreCase("send a message");
    }

    private boolean clickNodeOrClickableParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        int depth = 0;
        while (current != null && depth < 4) {
            if (current.isClickable() && current.isEnabled()) {
                boolean clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                if (current != node) {
                    current.recycle();
                }
                return clicked;
            }
            AccessibilityNodeInfo parent = current.getParent();
            if (current != node) {
                current.recycle();
            }
            current = parent;
            depth++;
        }
        if (current != null && current != node) {
            current.recycle();
        }
        return false;
    }

    private interface NodeMatcher {
        boolean matches(AccessibilityNodeInfo node);
    }

    /** Lowest visible matching node on screen. The caller must recycle the returned node. */
    private AccessibilityNodeInfo findNode(AccessibilityNodeInfo root, NodeMatcher matcher) {
        AccessibilityNodeInfo best = null;
        int bestTop = Integer.MIN_VALUE;
        Deque<AccessibilityNodeInfo> pending = new ArrayDeque<>();
        pending.push(root);
        int visited = 0;
        while (!pending.isEmpty() && visited < MAX_NODES) {
            AccessibilityNodeInfo node = pending.pop();
            visited++;
            boolean keep = false;
            try {
                if (!node.isVisibleToUser()) {
                    continue;
                }
                if (matcher.matches(node)) {
                    Rect bounds = new Rect();
                    node.getBoundsInScreen(bounds);
                    if (bounds.top >= bestTop) {
                        if (best != null && best != root) {
                            best.recycle();
                        }
                        best = node;
                        bestTop = bounds.top;
                        keep = true;
                    }
                }
                for (int i = 0; i < node.getChildCount() && visited + pending.size() < MAX_NODES; i++) {
                    AccessibilityNodeInfo child = node.getChild(i);
                    if (child != null) {
                        pending.push(child);
                    }
                }
            } finally {
                if (!keep && node != root) {
                    node.recycle();
                }
            }
        }
        while (!pending.isEmpty()) {
            AccessibilityNodeInfo left = pending.pop();
            if (left != root) {
                left.recycle();
            }
        }
        if (best == root) {
            // Never hand the caller the window root; it is recycled by the caller of this class.
            return null;
        }
        return best;
    }

    // ------------------------------------------------------------------ text helpers

    private static String clean(CharSequence value) {
        if (value == null) {
            return "";
        }
        String text = value.toString().replace('\u0000', ' ').trim();
        return text.replaceAll("\\s+", " ");
    }

    private static boolean containsGroupMarker(String text) {
        if (text == null || text.isEmpty()) {
            return false;
        }
        String value = text.toLowerCase(Locale.ROOT);
        // Chat headers vary by app version: some expose only a group name and member count,
        // rather than the literal label “群聊”. Do not require that exact UI string.
        return text.contains("群聊") || text.contains("群组") || text.contains("多人聊天")
                || text.contains("群成员") || text.contains("群设置")
                || GROUP_MEMBER_COUNT.matcher(text).matches()
                || value.contains("group chat") || value.contains("group members");
    }

    private static boolean isCandidate(String text) {
        return text != null && !text.isEmpty() && text.length() <= 800
                && !isUiControl(text) && !isSensitiveLike(text)
                && !isInternalDiagnosticText(text);
    }

    /** Defense in depth: never feed obvious app diagnostics/status text into chat memory. */
    private static boolean isInternalDiagnosticText(String text) {
        String value = text.toLowerCase(Locale.ROOT);
        return value.contains("诊断：待处理") || value.contains("诊斷：待處理")
                || value.contains("原生自动发送开关")
                || value.contains("本机观察历史") || value.contains("可见文字观察记录")
                || value.contains("已排入发送队列") || value.contains("模型请求失败")
                || value.contains("连接测试失败") || value.contains("openrouter api")
                || value.contains("回复：自动发送") || value.contains("回复：仅草稿")
                || value.contains("回复：关闭") || value.contains("昔涟思考中")
                || value.contains("昔涟（草稿）") || value.contains("昔涟（自动发送中）")
                || value.contains("昔涟 ai ·");
    }

    private static boolean isTimeLike(String text) {
        return TIME_LIKE.matcher(text.trim()).matches();
    }

    private static boolean isUiControl(String text) {
        String value = text.trim();
        return value.isEmpty() || value.equals("群聊") || value.equals("群聊设置")
                || value.equals("群聊成员") || value.equals("发送")
                || value.equals("返回") || value.equals("更多")
                || value.equals("复制") || value.equals("转发")
                || value.equals("评论") || value.equals("点赞")
                || value.equals("分享") || value.equals("输入消息")
                || value.equals("说点什么") || value.equals("聊天");
    }

    private static boolean isSensitiveLike(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        return lower.contains("cookie") || lower.contains("access_token")
                || lower.contains("authorization") || lower.contains("bearer ")
                || lower.contains("password") || lower.contains("passwd")
                || lower.contains("token") || text.contains("密码")
                || text.contains("口令") || text.contains("验证码")
                || text.contains("登录凭证");
    }

    private static final class PositionedText {
        final int top;
        final int left;
        final String text;

        PositionedText(int top, int left, String text) {
            this.top = top;
            this.left = left;
            this.text = text;
        }
    }

    private static final class PageSnapshot {
        boolean groupMarker;
        boolean hasComposer;
        final Set<String> fragments = new LinkedHashSet<>();
    }
}
