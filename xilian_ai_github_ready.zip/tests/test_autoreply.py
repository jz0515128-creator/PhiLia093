import unittest

from xilian_ai import autoreply


class FakeClock:
    def __init__(self, now=1000.0):
        self.now = now

    def __call__(self):
        return self.now

    def advance(self, seconds):
        self.now += seconds


class ModeTests(unittest.TestCase):
    def test_missing_setting_uses_default_auto_but_garbage_fails_safe_to_off(self):
        self.assertEqual(autoreply.DEFAULT_REPLY_MODE, autoreply.MODE_AUTO)
        self.assertEqual(autoreply.normalize_mode(None), autoreply.MODE_AUTO)
        self.assertEqual(autoreply.normalize_mode("whatever"), autoreply.MODE_OFF)
        self.assertEqual(autoreply.normalize_mode(""), autoreply.MODE_OFF)

    def test_cycle_goes_off_draft_auto_off(self):
        mode = autoreply.MODE_OFF
        seen = []
        for _ in range(4):
            mode = autoreply.next_mode(mode)
            seen.append(mode)
        self.assertEqual(seen, [autoreply.MODE_DRAFT, autoreply.MODE_AUTO,
                                autoreply.MODE_OFF, autoreply.MODE_DRAFT])


class InternalUiFilterTests(unittest.TestCase):
    def test_filters_diagnostic_text_but_keeps_normal_chat(self):
        self.assertTrue(autoreply.is_internal_ui_text("诊断：待处理 2 条"))
        self.assertTrue(autoreply.is_internal_ui_text("昔涟（草稿）：你好"))
        self.assertFalse(autoreply.is_internal_ui_text("昔涟，今天过得怎么样？"))

    def test_batcher_deduplicates_and_rejects_internal_ui(self):
        clock = FakeClock()
        batcher = autoreply.MessageBatcher(clock, quiet_s=0)
        batcher.add("诊断：待处理 2 条")
        batcher.add("你好")
        batcher.add("你好")
        self.assertEqual(batcher.take(), ["你好"])


class CleanReplyTests(unittest.TestCase):
    def test_collapses_whitespace_and_newlines(self):
        self.assertEqual(autoreply.clean_reply("你好\n\n  呀  "), "你好 呀")

    def test_is_truncated(self):
        self.assertEqual(len(autoreply.clean_reply("好" * 1000)), autoreply.MAX_REPLY_CHARS)

    def test_none_is_empty(self):
        self.assertEqual(autoreply.clean_reply(None), "")


class SendGateTests(unittest.TestCase):
    def test_automatic_cooldown_then_allowed(self):
        clock = FakeClock()
        gate = autoreply.SendGate(clock)
        self.assertTrue(gate.check(True)[0])
        gate.record()
        allowed, reason = gate.check(True)
        self.assertFalse(allowed)
        self.assertIn("冷", reason)
        clock.advance(autoreply.AUTO_MIN_INTERVAL_S + 1)
        self.assertTrue(gate.check(True)[0])

    def test_manual_cooldown_is_shorter(self):
        clock = FakeClock()
        gate = autoreply.SendGate(clock)
        gate.record()
        clock.advance(autoreply.MANUAL_MIN_INTERVAL_S + 1)
        self.assertTrue(gate.check(False)[0])
        self.assertFalse(gate.check(True)[0])

    def test_hourly_cap_and_recovery(self):
        clock = FakeClock()
        gate = autoreply.SendGate(clock)
        for _ in range(autoreply.MAX_SENDS_PER_HOUR):
            clock.advance(autoreply.AUTO_MIN_INTERVAL_S + 1)
            gate.record()
        clock.advance(autoreply.AUTO_MIN_INTERVAL_S + 1)
        allowed, reason = gate.check(True)
        self.assertFalse(allowed)
        self.assertIn("上限", reason)
        clock.advance(3600)
        self.assertTrue(gate.check(True)[0])


class MessageBatcherTests(unittest.TestCase):
    def test_waits_for_quiet_period(self):
        clock = FakeClock()
        batcher = autoreply.MessageBatcher(clock, quiet_s=4.0)
        batcher.add("第一句")
        self.assertFalse(batcher.ready())
        clock.advance(2)
        batcher.add("第二句")
        clock.advance(3)
        self.assertFalse(batcher.ready())
        clock.advance(2)
        self.assertTrue(batcher.ready())
        self.assertEqual(batcher.take(), ["第一句", "第二句"])
        self.assertFalse(batcher.ready())

    def test_blank_is_ignored_and_size_is_capped(self):
        clock = FakeClock()
        batcher = autoreply.MessageBatcher(clock, quiet_s=0, max_items=3)
        batcher.add("   ")
        for index in range(6):
            batcher.add(f"m{index}")
        self.assertEqual(batcher.take(), ["m3", "m4", "m5"])


if __name__ == "__main__":
    unittest.main()
