package org.xilian.xilianai;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

/** Private, process-shared state for the opt-in visible-text observer. */
public final class ObserverControl {
    private static final String PREFS = "xilian_observer_private";
    private static final String KEY_OBSERVING = "observing_enabled";
    private static final String KEY_CONNECTED = "service_connected";
    private static final String KEY_STATUS = "service_status";
    private static final String KEY_PENDING = "pending_observations";
    private static final String KEY_NEXT_SEQ = "next_sequence";
    private static final String KEY_DROPPED = "dropped_observations";
    private static final String KEY_BASELINE_RESET_GENERATION = "baseline_reset_generation";
    private static final int MAX_PENDING = 200;

    // Stage 2: outgoing replies. Hard limits are enforced here, independent of the Python UI.
    private static final String KEY_AUTO_SEND = "auto_send_enabled";
    private static final String KEY_OUTGOING = "outgoing_reply";
    private static final String KEY_LAST_RESULT = "last_send_result";
    private static final String KEY_SENT_TIMES = "sent_times_ms";
    private static final String KEY_OWN_SENT = "own_sent_texts";
    public static final int MAX_REPLY_CHARS = 300;
    private static final long AUTO_MIN_INTERVAL_MS = 30_000L;
    private static final long MANUAL_MIN_INTERVAL_MS = 5_000L;
    private static final int MAX_SENDS_PER_HOUR = 20;
    private static final long OUTGOING_TTL_MS = 120_000L;
    private static final long OWN_TEXT_TTL_MS = 30L * 60L * 1000L;
    private static final int MAX_OWN_TEXTS = 20;

    private ObserverControl() {}

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isObservingEnabled(Context context) {
        return prefs(context).getBoolean(KEY_OBSERVING, false);
    }

    /** Enabling is refused unless the user has explicitly enabled this service in Android Settings. */
    public static synchronized boolean setObservingEnabled(Context context, boolean enabled) {
        if (enabled && !isAccessibilityServiceEnabled(context)) {
            return false;
        }
        SharedPreferences p = prefs(context);
        boolean oldValue = p.getBoolean(KEY_OBSERVING, false);
        SharedPreferences.Editor editor = p.edit()
                .putBoolean(KEY_OBSERVING, enabled)
                .putString(KEY_STATUS, enabled ? "观察已启动；当前群聊将重新建立基线" : "观察已暂停");
        if (oldValue != enabled) {
            // This crosses the Python/Java boundary. The service can reset its in-memory
            // snapshot even if Douyin was not foregrounded when the user paused observation.
            editor.putLong(KEY_BASELINE_RESET_GENERATION,
                    p.getLong(KEY_BASELINE_RESET_GENERATION, 0L) + 1L);
        }
        editor.apply();
        return true;
    }

    public static long getBaselineResetGeneration(Context context) {
        return prefs(context).getLong(KEY_BASELINE_RESET_GENERATION, 0L);
    }

    public static boolean isAccessibilityServiceEnabled(Context context) {
        String enabledServices = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabledServices)) {
            return false;
        }
        ComponentName expected = new ComponentName(context, DouyinAccessibilityService.class);
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabledServices);
        for (String flattened : splitter) {
            ComponentName actual = ComponentName.unflattenFromString(flattened);
            if (expected.equals(actual)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isServiceConnected(Context context) {
        return prefs(context).getBoolean(KEY_CONNECTED, false);
    }

    public static String getStatus(Context context) {
        return prefs(context).getString(KEY_STATUS, "等待 Android 系统辅助功能服务连接");
    }

    public static String getPendingObservations(Context context) {
        return prefs(context).getString(KEY_PENDING, "[]");
    }

    public static long getDroppedCount(Context context) {
        return prefs(context).getLong(KEY_DROPPED, 0L);
    }

    public static synchronized void setServiceState(Context context, boolean connected, String status) {
        prefs(context).edit()
                .putBoolean(KEY_CONNECTED, connected)
                .putString(KEY_STATUS, status)
                .apply();
    }

    public static synchronized long appendObservation(
            Context context,
            String sessionId,
            String sender,
            String text,
            long observedAtMs,
            double confidence,
            String readStatus,
            boolean fresh) {
        SharedPreferences p = prefs(context);
        JSONArray queue;
        try {
            queue = new JSONArray(p.getString(KEY_PENDING, "[]"));
        } catch (JSONException | RuntimeException exception) {
            queue = new JSONArray();
        }

        long sequence = p.getLong(KEY_NEXT_SEQ, 0L) + 1L;
        try {
            JSONObject item = new JSONObject();
            item.put("seq", sequence);
            item.put("session_id", sessionId);
            item.put("sender", sender == null ? "" : sender);
            item.put("text", text);
            item.put("observed_at_ms", observedAtMs);
            item.put("confidence", confidence);
            item.put("read_status", readStatus);
            item.put("fresh", fresh);
            queue.put(item);
        } catch (JSONException exception) {
            return -1L;
        }

        long dropped = p.getLong(KEY_DROPPED, 0L);
        while (queue.length() > MAX_PENDING) {
            queue = removeFirst(queue);
            dropped++;
        }
        p.edit()
                .putLong(KEY_NEXT_SEQ, sequence)
                .putLong(KEY_DROPPED, dropped)
                .putString(KEY_PENDING, queue.toString())
                .apply();
        return sequence;
    }

    private static JSONArray removeFirst(JSONArray source) {
        JSONArray result = new JSONArray();
        for (int i = 1; i < source.length(); i++) {
            result.put(source.opt(i));
        }
        return result;
    }

    /** Acknowledge only entries already read by Python; later events remain queued. */
    public static synchronized void acknowledgeThrough(Context context, long sequence) {
        SharedPreferences p = prefs(context);
        JSONArray queue;
        try {
            queue = new JSONArray(p.getString(KEY_PENDING, "[]"));
        } catch (JSONException | RuntimeException exception) {
            p.edit().putString(KEY_PENDING, "[]").apply();
            return;
        }
        JSONArray remaining = new JSONArray();
        for (int i = 0; i < queue.length(); i++) {
            JSONObject item = queue.optJSONObject(i);
            if (item != null && item.optLong("seq", Long.MAX_VALUE) > sequence) {
                remaining.put(item);
            }
        }
        p.edit().putString(KEY_PENDING, remaining.toString()).apply();
    }


    // ------------------------------------------------------------------
    // Stage 2: sending replies into the Douyin group chat.
    // Nothing is sent unless (a) the user tapped "send to Douyin" for that exact draft,
    // or (b) the user switched the app to automatic mode. Both paths pass the limits below.
    // ------------------------------------------------------------------

    public static boolean isAutoSendEnabled(Context context) {
        return prefs(context).getBoolean(KEY_AUTO_SEND, false);
    }

    /** Enabling is refused unless the user has enabled this service in Android Settings. */
    public static boolean setAutoSendEnabled(Context context, boolean enabled) {
        if (enabled && !isAccessibilityServiceEnabled(context)) {
            return false;
        }
        SharedPreferences.Editor editor = prefs(context).edit().putBoolean(KEY_AUTO_SEND, enabled);
        String cancelledToken = "";
        if (!enabled) {
            // Switching automatic mode off also cancels an unsent automatic reply, and the
            // Python UI must get a result rather than leaving its pending token stuck forever.
            JSONObject pending = readOutgoing(context);
            if (pending != null && !pending.optBoolean("confirmed", false)) {
                cancelledToken = pending.optString("token", "");
                editor.remove(KEY_OUTGOING);
            }
        }
        editor.apply();
        if (!cancelledToken.isEmpty()) {
            setSendResult(context, cancelledToken, false,
                    "自动发送已关闭；待发回复已取消");
        }
        return true;
    }

    /** Returns null when a send is allowed now, otherwise a human-readable reason. */
    public static synchronized String rateLimitReason(Context context, boolean userConfirmed) {
        long now = System.currentTimeMillis();
        JSONArray times = prunedSentTimes(context, now);
        if (times.length() >= MAX_SENDS_PER_HOUR) {
            return "已达到每小时发送上限（" + MAX_SENDS_PER_HOUR + " 条）";
        }
        if (times.length() > 0) {
            long last = times.optLong(times.length() - 1, 0L);
            long minInterval = userConfirmed ? MANUAL_MIN_INTERVAL_MS : AUTO_MIN_INTERVAL_MS;
            if (now - last < minInterval) {
                return "发送冷却中，约 " + ((minInterval - (now - last)) / 1000L + 1L) + " 秒后可再发";
            }
        }
        return null;
    }

    private static JSONArray prunedSentTimes(Context context, long now) {
        JSONArray source;
        try {
            source = new JSONArray(prefs(context).getString(KEY_SENT_TIMES, "[]"));
        } catch (JSONException | RuntimeException exception) {
            source = new JSONArray();
        }
        JSONArray kept = new JSONArray();
        for (int i = 0; i < source.length(); i++) {
            long t = source.optLong(i, 0L);
            if (now - t < 3_600_000L && t <= now) {
                kept.put(t);
            }
        }
        return kept;
    }

    /**
     * Queue one reply for the service to type and send. Returns false (and records the reason
     * in the last-result slot) when refused. Only one reply may be pending at a time.
     */
    public static synchronized boolean queueOutgoing(
            Context context, String token, String text, boolean userConfirmed) {
        String body = text == null ? "" : text.replace('\u0000', ' ').trim();
        if (token == null || token.isEmpty()) {
            return false;
        }
        if (body.isEmpty() || body.length() > MAX_REPLY_CHARS) {
            setSendResult(context, token, false, "回复为空或超过 " + MAX_REPLY_CHARS + " 字，未发送");
            return false;
        }
        if (!userConfirmed && !isAutoSendEnabled(context)) {
            setSendResult(context, token, false, "自动发送未开启，未发送");
            return false;
        }
        if (!isAccessibilityServiceEnabled(context)) {
            setSendResult(context, token, false, "系统无障碍服务未启用，未发送");
            return false;
        }
        if (getOutgoing(context) != null) {
            setSendResult(context, token, false, "上一条回复仍在发送队列中，未重复排队");
            return false;
        }
        String reason = rateLimitReason(context, userConfirmed);
        if (reason != null) {
            setSendResult(context, token, false, reason);
            return false;
        }
        try {
            JSONObject item = new JSONObject();
            item.put("token", token);
            item.put("text", body);
            item.put("confirmed", userConfirmed);
            item.put("queued_at_ms", System.currentTimeMillis());
            prefs(context).edit().putString(KEY_OUTGOING, item.toString()).apply();
        } catch (JSONException exception) {
            setSendResult(context, token, false, "无法建立待发回复记录，未发送");
            return false;
        }
        setServiceStatusOnly(context, "已排入发送队列；请停留在抖音群聊页面（2 分钟内有效）");
        return true;
    }

    private static JSONObject readOutgoing(Context context) {
        String raw = prefs(context).getString(KEY_OUTGOING, "");
        if (raw == null || raw.isEmpty()) {
            return null;
        }
        try {
            return new JSONObject(raw);
        } catch (JSONException exception) {
            prefs(context).edit().remove(KEY_OUTGOING).apply();
            return null;
        }
    }

    /** The pending reply, or null. Expired replies are dropped and reported as such. */
    public static synchronized JSONObject getOutgoing(Context context) {
        JSONObject item = readOutgoing(context);
        if (item == null) {
            return null;
        }
        long age = System.currentTimeMillis() - item.optLong("queued_at_ms", 0L);
        if (age > OUTGOING_TTL_MS || age < -5_000L) {
            prefs(context).edit().remove(KEY_OUTGOING).apply();
            setSendResult(context, item.optString("token"), false,
                    "等待超时（未在 2 分钟内回到抖音群聊页面），已取消");
            return null;
        }
        return item;
    }

    public static boolean hasOutgoing(Context context) {
        return readOutgoing(context) != null;
    }

    public static synchronized void clearOutgoing(Context context) {
        cancelOutgoing(context, "系统无障碍服务已中断或断开；待发回复已取消");
    }

    /** Cancel an unsent reply with a reason visible to the Python UI. */
    public static synchronized void cancelOutgoing(Context context, String detail) {
        JSONObject pending = readOutgoing(context);
        prefs(context).edit().remove(KEY_OUTGOING).apply();
        if (pending != null) {
            setSendResult(context, pending.optString("token"), false,
                    detail == null || detail.trim().isEmpty() ? "待发回复已取消" : detail.trim());
        }
    }

    public static synchronized void failOutgoing(Context context, String token, String detail) {
        prefs(context).edit().remove(KEY_OUTGOING).apply();
        setSendResult(context, token, false, detail);
    }

    public static synchronized void recordSent(Context context, String token, String text) {
        long now = System.currentTimeMillis();
        JSONArray times = prunedSentTimes(context, now);
        times.put(now);

        JSONArray own;
        try {
            own = new JSONArray(prefs(context).getString(KEY_OWN_SENT, "[]"));
        } catch (JSONException | RuntimeException exception) {
            own = new JSONArray();
        }
        JSONArray ownKept = new JSONArray();
        for (int i = 0; i < own.length(); i++) {
            JSONObject entry = own.optJSONObject(i);
            if (entry != null && now - entry.optLong("at", 0L) < OWN_TEXT_TTL_MS) {
                ownKept.put(entry);
            }
        }
        try {
            JSONObject entry = new JSONObject();
            entry.put("text", normalizeForCompare(text));
            entry.put("at", now);
            ownKept.put(entry);
        } catch (JSONException ignored) {
            // The own-text list is a best-effort loop guard.
        }
        while (ownKept.length() > MAX_OWN_TEXTS) {
            ownKept = removeFirst(ownKept);
        }
        prefs(context).edit()
                .remove(KEY_OUTGOING)
                .putString(KEY_SENT_TIMES, times.toString())
                .putString(KEY_OWN_SENT, ownKept.toString())
                .apply();
        setSendResult(context, token, true, "已点击抖音发送按钮；无法确认平台最终送达状态");
    }

    /** True when the text is something this app recently sent, so it must not be answered again. */
    public static synchronized boolean isOwnRecentText(Context context, String fragment) {
        if (fragment == null || fragment.isEmpty()) {
            return false;
        }
        String wanted = normalizeForCompare(fragment);
        long now = System.currentTimeMillis();
        try {
            JSONArray own = new JSONArray(prefs(context).getString(KEY_OWN_SENT, "[]"));
            for (int i = 0; i < own.length(); i++) {
                JSONObject entry = own.optJSONObject(i);
                if (entry != null && now - entry.optLong("at", 0L) < OWN_TEXT_TTL_MS
                        && wanted.equals(entry.optString("text"))) {
                    return true;
                }
            }
        } catch (JSONException | RuntimeException exception) {
            return false;
        }
        return false;
    }

    public static String normalizeForCompare(String text) {
        if (text == null) {
            return "";
        }
        return text.replace('\u0000', ' ').trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    public static synchronized void setSendResult(
            Context context, String token, boolean ok, String detail) {
        try {
            JSONObject result = new JSONObject();
            result.put("token", token == null ? "" : token);
            result.put("ok", ok);
            result.put("detail", detail == null ? "" : detail);
            result.put("at_ms", System.currentTimeMillis());
            prefs(context).edit()
                    .putString(KEY_LAST_RESULT, result.toString())
                    .putString(KEY_STATUS, (ok ? "发送成功：" : "未发送：") + detail)
                    .apply();
        } catch (JSONException ignored) {
            // Status reporting must never crash the accessibility service.
        }
    }

    private static void setServiceStatusOnly(Context context, String status) {
        prefs(context).edit().putString(KEY_STATUS, status).apply();
    }

    public static String getLastSendResult(Context context) {
        return prefs(context).getString(KEY_LAST_RESULT, "");
    }

    public static synchronized void clearSendState(Context context) {
        prefs(context).edit()
                .remove(KEY_OUTGOING)
                .remove(KEY_LAST_RESULT)
                .apply();
    }

    public static synchronized void clearPendingObservations(Context context) {
        prefs(context).edit()
                .putString(KEY_PENDING, "[]")
                .putLong(KEY_DROPPED, 0L)
                .apply();
    }
}
