import json
import os
import threading
import uuid

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.screenmanager import ScreenManager, Screen

from xilian_ai import autoreply, store
from xilian_ai.engine import AIEngine, AIEngineError

OPENROUTER_API_BASE = "https://openrouter.ai/api/v1"
DEEPSEEK_MODEL = "deepseek/deepseek-v4.1-flash"
AI_CONFIG_PROFILE = "openrouter-deepseek-v4.1-flash"

FONT_CANDIDATES = [
    "/system/fonts/NotoSansCJK-Regular.ttc",
    "/system/fonts/NotoSansSC-Regular.otf",
    "/system/fonts/NotoSansHans-Regular.otf",
    "/system/fonts/DroidSansFallback.ttf",
    "/system/fonts/DroidSansFallbackFull.ttf",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
]


def setup_font():
    for path in FONT_CANDIDATES:
        if os.path.exists(path):
            LabelBase.register(name="CJK", fn_regular=path)
            return "CJK"
    return "Roboto"


FONT = setup_font()
Window.softinput_mode = "resize"


def field(**kw):
    kw.setdefault("input_type", "text")
    kw.setdefault("keyboard_suggestions", True)
    return TextInput(font_name=FONT, multiline=False, size_hint_y=None,
                     height=dp(44), write_tab=False, **kw)


def label(text, **kw):
    kw.setdefault("size_hint_y", None)
    kw.setdefault("halign", "left")
    lb = Label(text=text, font_name=FONT, **kw)
    lb.bind(width=lambda w, v: setattr(w, "text_size", (v, None)),
            texture_size=lambda w, v: setattr(w, "height", v[1] + dp(8)))
    return lb


def android_observer_bridge():
    """Load the native bridge only on Android, so host-side tests need no pyjnius."""
    from jnius import autoclass

    activity_class = autoclass("org.kivy.android.PythonActivity")
    activity = activity_class.mActivity
    if activity is None:
        raise RuntimeError("Android Activity 尚未就緒")
    controller = autoclass("org.xilian.xilianai.ObserverControl")
    return activity, controller


def request_send_tick():
    """Ask the accessibility service to start sending right away (best effort)."""
    try:
        from jnius import autoclass

        autoclass("org.xilian.xilianai.DouyinAccessibilityService").requestTick()
    except Exception:
        pass


class SettingsScreen(Screen):
    def __init__(self, app, **kw):
        super().__init__(name="settings", **kw)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(10))
        root.add_widget(label("昔涟 AI · 设置", font_size="22sp"))
        root.add_widget(label("OpenRouter API 地址"))
        self.base = field(text=app.cfg.get("API_BASE_URL", OPENROUTER_API_BASE))
        root.add_widget(self.base)
        root.add_widget(label("API Key"))
        self.key = field(text=app.cfg.get("API_KEY", ""), password=True)
        root.add_widget(self.key)
        root.add_widget(label("模型名称"))
        self.model = field(text=app.cfg.get("MODEL", DEEPSEEK_MODEL))
        root.add_widget(self.model)
        self.tip = label("", color=(1, 0.6, 0.6, 1))
        root.add_widget(self.tip)
        root.add_widget(BoxLayout())
        test_btn = Button(text="测试 OpenRouter 连接", font_name=FONT,
                          size_hint_y=None, height=dp(48))
        test_btn.bind(on_release=self.test_connection)
        root.add_widget(test_btn)
        btn = Button(text="保存并开始", font_name=FONT, size_hint_y=None, height=dp(52))
        btn.bind(on_release=self.save)
        root.add_widget(btn)
        self.add_widget(root)

    def save(self, *_):
        cfg = {"API_BASE_URL": self.base.text.strip(),
               "API_KEY": self.key.text.strip(),
               "MODEL": self.model.text.strip(),
               "AI_CONFIG_PROFILE": AI_CONFIG_PROFILE}
        if not all(cfg.values()):
            self.tip.text = "三项都需要填写"
            return
        self.app.save_cfg(cfg)
        self.manager.current = "chat"

    def test_connection(self, *_):
        base_url = self.base.text.strip()
        api_key = self.key.text.strip()
        model = self.model.text.strip()
        if not all((base_url, api_key, model)):
            self.tip.text = "請填寫 OpenRouter API 地址、API Key 與模型名稱"
            return
        self.tip.text = "正在以「你好，昔涟」測試連線…"
        threading.Thread(
            target=self._run_connection_test,
            args=(base_url, api_key, model),
            daemon=True,
        ).start()

    def _run_connection_test(self, base_url, api_key, model):
        try:
            result = AIEngine(base_url, api_key, model).decide("群友：你好，昔涟")
            reply = result["reply"].strip()
            has_chinese = any("\u4e00" <= char <= "\u9fff" for char in reply)
            if not result["should_reply"] or not reply or not has_chinese:
                raise AIEngineError("模型未返回預期的中文回覆，請檢查模型與 API 設定。")
            message = f"連線成功；昔涟回覆：{reply}"
        except Exception as exc:
            message = f"連線測試失敗：{exc}"
        Clock.schedule_once(lambda _dt: setattr(self.tip, "text", message))


class ChatScreen(Screen):
    def __init__(self, app, **kw):
        super().__init__(name="chat", **kw)
        self.app = app
        self._request_pending = False
        self._work_generation = 0
        self._retry_generation = 0
        self.gate = autoreply.SendGate()
        self.batcher = autoreply.MessageBatcher()
        self._awaiting = {}
        self._shown_result_token = ""
        self._last_event = "等待新消息"
        self._tick_error = ""
        self._mode_hint_text = ""
        self._config_notice_shown = False
        # Retry work items are separate from live messages, so retrying an old failed batch
        # cannot merge it into or overwrite newer incoming messages.
        self._retry_queue = []
        root = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
        top = BoxLayout(size_hint_y=None, height=dp(44))
        top.add_widget(label("昔涟 AI · 阶段 2 回复", font_size="18sp"))
        gear = Button(text="设置", font_name=FONT, size_hint_x=None, width=dp(72))
        gear.bind(on_release=lambda *_: setattr(self.manager, "current", "settings"))
        top.add_widget(gear)
        root.add_widget(top)
        observer_row = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(4))
        self.observer_status = label(
            "觀察已暫停；僅保存可確認群聊中的可見文字片段。",
            font_size="11sp",
        )
        observer_row.add_widget(self.observer_status)
        self.observer_button = Button(text="系統設置", font_name=FONT,
                                      size_hint_x=None, width=dp(82))
        self.observer_button.bind(on_release=self.toggle_observer)
        observer_row.add_widget(self.observer_button)
        clear_button = Button(text="清空觀察", font_name=FONT,
                              size_hint_x=None, width=dp(78))
        clear_button.bind(on_release=self.clear_observation_log)
        observer_row.add_widget(clear_button)
        root.add_widget(observer_row)
        mode_row = BoxLayout(size_hint_y=None, height=dp(64), spacing=dp(4))
        self.reply_status = label("", font_size="11sp")
        mode_row.add_widget(self.reply_status)
        self.test_button = Button(text="測試", font_name=FONT, size_hint_x=None, width=dp(56))
        self.test_button.bind(on_release=self.test_reply)
        mode_row.add_widget(self.test_button)
        self.mode_button = Button(text="", font_name=FONT, size_hint_x=None, width=dp(128))
        self.mode_button.bind(on_release=self.cycle_reply_mode)
        mode_row.add_widget(self.mode_button)
        root.add_widget(mode_row)
        self.scroll = ScrollView()
        self.log = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(8))
        self.log.bind(minimum_height=self.log.setter("height"))
        self._observation_widgets = []
        self.scroll.add_widget(self.log)
        root.add_widget(self.scroll)
        bottom = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(6))
        self.sender = TextInput(text="群友", font_name=FONT, multiline=False,
                                input_type="text", keyboard_suggestions=True,
                                size_hint_x=0.22)
        self.msg = TextInput(hint_text="输入群友消息…", font_name=FONT,
                             multiline=False, input_type="text",
                             keyboard_suggestions=True)
        self.msg.bind(on_text_validate=self.send)
        send = Button(text="发送", font_name=FONT, size_hint_x=0.2)
        send.bind(on_release=self.send)
        for w in (self.sender, self.msg, send):
            bottom.add_widget(w)
        root.add_widget(bottom)
        self.add_widget(root)
        self.say("預設回覆模式為「自动发送」：開啟系統無障礙並按「開始觀察」後，"
                 "群聊新消息會由昔涟自動回覆（冷卻 30 秒、每小時最多 20 條）。"
                 "不想自動發送時，點右上角的模式按鈕切到「仅草稿」或「關閉」。",
                 (1, 0.85, 0.5, 1))
        self._sync_mode_to_service()
        self._update_mode_ui()
        for record in reversed(store.recent_observations(30)):
            _session, _sender, text, observed_at, _timestamp, confidence, status = record
            self.show_observation(
                f"本機觀察歷史 · {observed_at} · {confidence:.0%}\n{status}\n{text}"
            )
        self._observer_poll = Clock.schedule_interval(self.refresh_observer, 1.0)
        Clock.schedule_once(self.refresh_observer, 0)

    def say(self, text, color=(1, 1, 1, 1)):
        self.log.add_widget(label(text, color=color))
        Clock.schedule_once(lambda dt: setattr(self.scroll, "scroll_y", 0), 0.1)

    def show_observation(self, text):
        widget = label(text, color=(0.85, 0.85, 0.85, 1))
        self._observation_widgets.append(widget)
        self.log.add_widget(widget)
        Clock.schedule_once(lambda dt: setattr(self.scroll, "scroll_y", 0), 0.1)

    def toggle_observer(self, *_):
        try:
            activity, controller = android_observer_bridge()
            if controller.isObservingEnabled(activity):
                controller.setObservingEnabled(activity, False)
                self._work_generation += 1
                self._retry_generation += 1
                self.batcher.clear()
                self._retry_queue.clear()
                try:
                    controller.cancelOutgoing(activity, "观察已暂停；待发回复已取消")
                except Exception:
                    pass
                self.say("抖音可見文字觀察已暫停；尚未发送的自动回复已取消。", (1, 0.8, 0.5, 1))
                self.refresh_observer()
                return
            if not controller.isAccessibilityServiceEnabled(activity):
                self.observer_status.text = "需由你在 Android 系統設定中手動啟用，App 不會代授權。"
                Intent = __import__("jnius").autoclass("android.content.Intent")
                Settings = __import__("jnius").autoclass("android.provider.Settings")
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return
            if not controller.setObservingEnabled(activity, True):
                self.observer_status.text = "系統輔助功能未啟用，觀察保持暫停。"
                return
            self.say("可見文字觀察已啟動。是否發送回覆由右側「回复」模式決定（目前模式會顯示在右側）。",
                     (0.7, 0.9, 0.7, 1))
            self.refresh_observer()
        except Exception:
            self.observer_status.text = "無法讀取 Android 輔助功能狀態；觀察未確認啟動。"

    def clear_observation_log(self, *_):
        try:
            activity, controller = android_observer_bridge()
            controller.clearPendingObservations(activity)
        except Exception:
            pass
        store.clear_observations()
        self.batcher.clear()
        self._retry_queue.clear()
        self._work_generation += 1
        self._retry_generation += 1
        for widget in self._observation_widgets:
            if widget.parent is self.log:
                self.log.remove_widget(widget)
        self._observation_widgets.clear()
        self.say("本機可見文字觀察記錄已清空。", (0.8, 0.8, 0.8, 1))

    def refresh_observer(self, *_):
        self._refresh_observation_status()
        try:
            self._reply_tick()
            self._tick_error = ""
        except Exception as exc:
            self._tick_error = f"{type(exc).__name__}: {exc}"
        self._update_diag()

    def _update_diag(self):
        try:
            activity, controller = android_observer_bridge()
            flag = "開" if controller.isAutoSendEnabled(activity) else "關"
        except Exception:
            flag = "未知"
        pending = len(self.batcher) + len(self._retry_queue)
        lines = [self._mode_hint_text,
                 f"診斷：待處理 {pending} 批/條｜原生自動發送開關：{flag}｜{self._last_event}"]
        if self._tick_error:
            lines.append(f"錯誤：{self._tick_error[:120]}")
        self.reply_status.text = "\n".join(lines)

    def _refresh_observation_status(self):
        try:
            activity, controller = android_observer_bridge()
            raw = str(controller.getPendingObservations(activity))
            observations = json.loads(raw)
            observing_now = bool(controller.isObservingEnabled(activity))
            last_sequence = 0
            for item in observations:
                last_sequence = max(last_sequence, int(item.get("seq", 0)))
                text = str(item.get("text", ""))
                # Filter before persistence and before reply routing: diagnostics must never
                # become a simulated user message or trigger an automatic reply.
                if autoreply.is_internal_ui_text(text):
                    self._last_event = "已过滤疑似昔涟 AI 诊断/后台文字，不保存为群聊消息"
                    continue
                is_fresh = bool(item.get("fresh"))
                confidence = float(item.get("confidence", 0.0))
                was_recorded = store.record_observation(item)
                if was_recorded:
                    tag = "【新消息】" if is_fresh else "【基線】"
                    self.show_observation(
                        f"{tag}抖音可見文字片段（{confidence:.0%}；可能不完整，發送者未確認）：\n{text}"
                    )
                # Reply routing is independent from history UI deduplication. Otherwise two
                # different people sending the same short text within 3 seconds could be lost.
                if is_fresh:
                    if not observing_now:
                        self._last_event = "收到暂停前遗留的观测记录；未排入自动回复"
                    elif self.reply_mode != autoreply.MODE_OFF:
                        self.batcher.add(text)
                        self._last_event = "侦测到新消息，等待 4 秒安静后呼叫模型"
                    else:
                        self._last_event = "侦测到新消息，但回覆模式為關閉"
            if last_sequence:
                controller.acknowledgeThrough(activity, last_sequence)

            system_enabled = bool(controller.isAccessibilityServiceEnabled(activity))
            observing = bool(controller.isObservingEnabled(activity))
            if not system_enabled:
                self.observer_button.text = "系統設置"
                status = "系統輔助功能尚未啟用；未讀取抖音頁面。"
            elif not observing:
                self.observer_button.text = "開始觀察"
                status = "系統服務已授權，但觀察已暫停。"
            else:
                self.observer_button.text = "暫停觀察"
                status = str(controller.getStatus(activity))
            dropped = int(controller.getDroppedCount(activity))
            if dropped:
                status += f"（待處理佇列曾丟棄 {dropped} 條，記錄可能不完整）"
            self.observer_status.text = "狀態：" + status
        except Exception:
            self.observer_button.text = "系統設置"
            self.observer_status.text = "觀察狀態不可用；不表示已收到或保存任何抖音消息。"

    # ------------------------------------------------------------------ stage 2: replies

    @property
    def reply_mode(self):
        return autoreply.normalize_mode(self.app.cfg.get("REPLY_MODE"))

    def _update_mode_ui(self):
        mode = self.reply_mode
        self.mode_button.text = autoreply.MODE_LABELS[mode]
        self._mode_hint_text = {
            autoreply.MODE_OFF: "不會呼叫模型，也不會發送任何消息。",
            autoreply.MODE_DRAFT: "新消息會產生草稿；按「發送到抖音」才會發出。",
            autoreply.MODE_AUTO: "新消息會自動回覆（冷卻 30 秒、每小時最多 20 條）。",
        }[mode]
        self.reply_status.text = self._mode_hint_text

    def _set_service_auto_flag(self, enabled):
        activity, controller = android_observer_bridge()
        return bool(controller.setAutoSendEnabled(activity, bool(enabled)))

    def _sync_mode_to_service(self):
        """The native auto-send switch must never be on while the app says it is off."""
        try:
            self._set_service_auto_flag(self.reply_mode == autoreply.MODE_AUTO)
        except Exception:
            pass

    def _ensure_auto_flag(self):
        """In auto mode, turn the native switch on as soon as the system service is enabled.

        With auto as the default, the service is usually not enabled yet at app start, so the
        first attempt in _sync_mode_to_service is refused; retry here until it sticks.
        """
        if self.reply_mode != autoreply.MODE_AUTO:
            return
        activity, controller = android_observer_bridge()
        if (not controller.isAutoSendEnabled(activity)
                and controller.isAccessibilityServiceEnabled(activity)):
            controller.setAutoSendEnabled(activity, True)

    def _apply_mode(self, mode):
        mode = autoreply.normalize_mode(mode)
        if mode == autoreply.MODE_AUTO:
            try:
                if not self._set_service_auto_flag(True):
                    self.say("系統輔助功能尚未啟用，無法開啟自動發送；已改為「仅草稿」。",
                             (1, 0.6, 0.6, 1))
                    mode = autoreply.MODE_DRAFT
            except Exception:
                self.say("無法連接 Android 服務，自動發送保持關閉；已改為「仅草稿」。",
                         (1, 0.6, 0.6, 1))
                mode = autoreply.MODE_DRAFT
        if mode != autoreply.MODE_AUTO:
            try:
                self._set_service_auto_flag(False)
            except Exception:
                pass
        if mode == autoreply.MODE_OFF:
            self.batcher.clear()
            self._retry_queue.clear()
            self._work_generation += 1
            self._retry_generation += 1
            try:
                activity, controller = android_observer_bridge()
                controller.cancelOutgoing(activity, "回覆模式已关闭；待发回复已取消")
            except Exception:
                pass
        cfg = dict(self.app.cfg)
        cfg["REPLY_MODE"] = mode
        self.app.save_cfg(cfg)
        self._update_mode_ui()

    def cycle_reply_mode(self, *_):
        target = autoreply.next_mode(self.reply_mode)
        if target != autoreply.MODE_AUTO:
            self._apply_mode(target)
            return
        box = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        box.add_widget(label(
            "開啟後，昔涟會在抖音群聊裡以【你的帳號】自動發言，群友看到的是你的帳號發出的消息。\n"
            "• 发言者识别受抖音界面结构限制；无法确认来源的可见文字仍可能被误判\n"
            "• 自動操作可能違反平台規則並影響帳號\n"
            "• 隨時可在此切換回「關閉」",
            font_size="14sp"))
        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        cancel = Button(text="取消", font_name=FONT)
        confirm = Button(text="我了解，開啟", font_name=FONT)
        row.add_widget(cancel)
        row.add_widget(confirm)
        box.add_widget(row)
        popup = Popup(title="開啟自動發送？", title_font=FONT, content=box,
                      size_hint=(0.92, None), height=dp(330), auto_dismiss=False)
        cancel.bind(on_release=lambda *_: popup.dismiss())

        def accept(*_):
            popup.dismiss()
            self._apply_mode(autoreply.MODE_AUTO)

        confirm.bind(on_release=accept)
        popup.open()

    def _reply_tick(self):
        """Collect send results and process a quiet batch or a user-requested retry."""
        self._ensure_auto_flag()
        self._poll_send_result()
        if self.reply_mode == autoreply.MODE_OFF or self._request_pending:
            return

        has_retry = bool(self._retry_queue)
        if not has_retry and not self.batcher.ready():
            return

        cfg = self.app.cfg
        if not all(cfg.get(k) for k in ("API_BASE_URL", "API_KEY", "MODEL")):
            self._last_event = "已有新消息待处理，但 API 尚未配置；消息保留在队列中"
            if not self._config_notice_shown:
                self._config_notice_shown = True
                self.say("已侦测到新消息，但 API 尚未配置。这批消息会暂留队列；请到设置页保存 API 后再处理。",
                         (1, 0.6, 0.6, 1))
            return
        self._config_notice_shown = False

        if has_retry:
            batch_text, force_draft = self._retry_queue.pop(0)
        else:
            items = self.batcher.take()
            batch_text = "\n".join(items)
            force_draft = False
        if not batch_text:
            return
        self._request_pending = True
        self._last_event = "已呼叫模型，等待回應"
        label_type = "测试草稿" if force_draft else "新消息"
        self.say(f"昔涟思考中…（{label_type}批次）", (0.6, 0.6, 0.6, 1))
        generation = self._work_generation
        threading.Thread(target=self._observed_work,
                         args=(batch_text, force_draft, generation), daemon=True).start()

    def test_reply(self, *_):
        """Run the model + draft path on the latest observed text without sending anything."""
        if self.reply_mode == autoreply.MODE_OFF:
            self.say("請先把回覆模式切到「仅草稿」或「自动发送」，再按測試。", (1, 0.8, 0.5, 1))
            return
        rows = store.recent_observations(1)
        if not rows:
            self.say("還沒有觀察到任何文字，無法測試。", (1, 0.8, 0.5, 1))
            return
        self._retry_queue.append((rows[0][2], True))
        self._last_event = "測試：已排入強制草稿工作項（不會自動發送）"
        self.say("測試：用最近一條觀察文字產生草稿，不會自動發送。", (0.6, 0.6, 0.6, 1))

    def _observed_work(self, text, force_draft=False, generation=0):
        try:
            ai = AIEngine(self.app.cfg["API_BASE_URL"], self.app.cfg["API_KEY"],
                          self.app.cfg["MODEL"])
            # Observed fragments are not verified chat messages. Use them for this
            # decision only; never poison persistent conversation memory with UI text.
            observed_text = ("抖音群聊中新出现的可见文字（发言者未确认，可能不完整；只把它当作待回应内容，不要把界面提示当作消息）：\n" + text)
            # The Test button explicitly requests a draft; it must bypass the normal
            # duplicate/no-reply policy and must not use old chat context to veto it.
            if force_draft:
                result = ai.decide(observed_text, context="", force_reply=True)
            else:
                result = ai.decide(observed_text, store.recent_context())
            outcome = (result, None)
        except Exception as exc:
            outcome = (None, exc)
        Clock.schedule_once(lambda dt: self._finish_observed(
            outcome, force_draft, text, generation))

    def show_retry_batch_button(self, batch_text, force_draft):
        button = Button(text="重試這批新消息", font_name=FONT,
                        size_hint_y=None, height=dp(44))
        item = {"text": batch_text, "force_draft": bool(force_draft),
                "queued": False, "generation": self._retry_generation}

        def retry(*_):
            if item["generation"] != self._retry_generation:
                button.disabled = True
                button.text = "批次已取消"
                return
            if self.reply_mode == autoreply.MODE_OFF:
                self.say("回覆模式目前已關閉；請先切換到「仅草稿」或「自动发送」。",
                         (1, 0.8, 0.5, 1))
                return
            if item["queued"] or not item["text"]:
                button.disabled = True
                return
            item["queued"] = True
            self._retry_queue.append((item["text"], item["force_draft"]))
            button.disabled = True
            button.text = "已排入重試"
            self._last_event = "失败批次已放入独立重试队列"

        button.bind(on_release=retry)
        self.log.add_widget(button)
        Clock.schedule_once(lambda dt: setattr(self.scroll, "scroll_y", 0), 0.1)

    def _finish_observed(self, outcome, force_draft=False, source_text="", generation=0):
        self._request_pending = False
        result, error = outcome
        stale_work = generation != self._work_generation
        if error is not None:
            if stale_work:
                self._last_event = "观察/回复模式已改变；旧批次已取消，不会自动重试"
                self.say("请求失败，但观察或回复模式已改变；旧批次未重新排队。", (0.8, 0.8, 0.8, 1))
                return
            self._last_event = "模型請求失敗；这批消息已保留，可手动重试"
            self.say(f"請求失敗：{type(error).__name__}: {error}\n"
                     "這批新消息沒有自動重送，以免 API 故障時無限重試；可按下方按鈕重試。",
                     (1, 0.5, 0.5, 1))
            self.show_retry_batch_button(source_text, force_draft)
            return
        reply = autoreply.clean_reply(result.get("reply", ""))
        if not result.get("should_reply") or not reply:
            self._last_event = "模型判斷暫不回應"
            if force_draft:
                self.say(f"測試未產生草稿：模型沒有返回可用回覆。{result.get('reason', '')}", (1, 0.6, 0.5, 1))
            else:
                self.say(f"昔涟選擇暫不回應。{result.get('reason', '')}", (0.7, 0.7, 0.7, 1))
            return
        mode = self.reply_mode
        if mode == autoreply.MODE_OFF:
            return
        if stale_work:
            self._last_event = "观察/回复模式已改变；该结果不会自动发送"
            self.say("这批消息的模型结果已返回，但观察或回复模式已改变；只保留草稿，不自动发送。",
                     (1, 0.8, 0.5, 1))
            self.show_draft(reply, result.get("reason", ""))
            return
        if mode == autoreply.MODE_AUTO and not force_draft:
            allowed, why = self.gate.check(automatic=True)
            if allowed and self.queue_reply(reply, confirmed=False):
                self.say(f"昔涟（自動發送中）：{reply}\n判斷依據：{result.get('reason', '')}",
                         (1, 0.85, 0.9, 1))
                return
            if not allowed:
                self.say(f"未自動發送：{why}。草稿保留，可手動發送。", (1, 0.8, 0.5, 1))
        self.show_draft(reply, result.get("reason", ""))

    def show_draft(self, reply, reason):
        box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(4))
        box.bind(minimum_height=box.setter("height"))
        box.add_widget(label(f"昔涟（草稿）：{reply}\n判斷依據：{reason}", color=(1, 0.85, 0.9, 1)))
        button = Button(text="發送到抖音", font_name=FONT, size_hint_y=None, height=dp(44))

        def send_draft(*_):
            button.disabled = True
            ok = self.queue_reply(reply, confirmed=True)
            button.text = "已排入發送" if ok else "未能排入（見下方原因）"

        button.bind(on_release=send_draft)
        box.add_widget(button)
        self.log.add_widget(box)
        Clock.schedule_once(lambda dt: setattr(self.scroll, "scroll_y", 0), 0.1)

    def queue_reply(self, reply, confirmed):
        allowed, why = self.gate.check(automatic=not confirmed)
        if not allowed:
            self.say(f"未發送：{why}", (1, 0.8, 0.5, 1))
            return False
        token = uuid.uuid4().hex
        try:
            activity, controller = android_observer_bridge()
            ok = bool(controller.queueOutgoing(activity, token, reply, bool(confirmed)))
        except Exception:
            self.say("無法連接 Android 服務，未發送。", (1, 0.6, 0.6, 1))
            return False
        if not ok:
            self._poll_send_result(force_token=token)
            return False
        self._awaiting[token] = reply
        self._last_event = "已排入發送隊列，等待服務填字"
        request_send_tick()
        self.say("已排入發送隊列：請停留在抖音群聊頁面（2 分鐘內有效）。", (0.7, 0.9, 0.7, 1))
        return True

    def _poll_send_result(self, force_token=""):
        activity, controller = android_observer_bridge()
        raw = str(controller.getLastSendResult(activity))
        if not raw:
            return
        result = json.loads(raw)
        token = str(result.get("token", ""))
        if not token or token == self._shown_result_token:
            return
        if token not in self._awaiting and token != force_token:
            return
        self._shown_result_token = token
        reply = self._awaiting.pop(token, "")
        detail = str(result.get("detail", ""))
        self._last_event = "發送成功" if result.get("ok") else f"發送失敗：{detail[:40]}"
        if result.get("ok"):
            self.gate.record()
            if reply:
                store.add_message("昔涟", reply)
            self.say(f"已触发抖音发送动作（未确认平台最终送达）：{reply}", (0.7, 0.9, 0.7, 1))
        else:
            self.say(f"未發送：{detail}", (1, 0.8, 0.5, 1))

    def send(self, *_):
        text = self.msg.text.strip()
        if not text:
            return
        if self._request_pending:
            return
        who = self.sender.text.strip() or "群友"
        self.say(f"{who}：{text}", (0.7, 0.85, 1, 1))
        cfg = self.app.cfg
        if not all(cfg.get(k) for k in ("API_BASE_URL", "API_KEY", "MODEL")):
            self.say("請先在設定中填寫 API 信息", (1, 0.6, 0.6, 1))
            return
        self._request_pending = True
        self.say("昔涟思考中…", (0.6, 0.6, 0.6, 1))
        threading.Thread(target=self.work, args=(who, text), daemon=True).start()

    def work(self, who, text):
        success = False
        try:
            ai = AIEngine(self.app.cfg["API_BASE_URL"], self.app.cfg["API_KEY"],
                          self.app.cfg["MODEL"])
            r = ai.decide(f"{who}: {text}", store.recent_context())
            store.add_message(who, text)
            if r["should_reply"] and r["reply"].strip():
                store.add_message("昔涟AI建议", r["reply"].strip())
                out = (f"昔涟（待发送）：{r['reply'].strip()}\n判断依据：{r['reason']}",
                       (1, 0.85, 0.9, 1))
            else:
                out = (f"昔涟選擇暫不回應。{r['reason']}", (0.7, 0.7, 0.7, 1))
            success = True
        except Exception as exc:
            out = (f"請求失敗：{type(exc).__name__}: {exc}\n"
                   "原訊息仍保留在輸入框；請檢查 OpenRouter API 地址、金鑰、模型名稱或額度。",
                   (1, 0.5, 0.5, 1))
        Clock.schedule_once(lambda dt: self._finish_request(text, success, out))

    def _finish_request(self, text, success, out):
        self._request_pending = False
        if success and self.msg.text.strip() == text:
            self.msg.text = ""
        self.say(*out)


class XilianApp(App):
    title = "昔涟 AI"

    def build(self):
        self.cfg_path = os.path.join(self.user_data_dir, "config.json")
        store.set_db_path(os.path.join(self.user_data_dir, "xilian_memory.sqlite3"))
        store.init_db()
        try:
            with open(self.cfg_path, encoding="utf-8") as f:
                self.cfg = json.load(f)
        except Exception:
            self.cfg = {}
        if self.cfg.get("AI_CONFIG_PROFILE") != AI_CONFIG_PROFILE:
            previous_base = self.cfg.get("API_BASE_URL", "").rstrip("/")
            if previous_base != OPENROUTER_API_BASE:
                self.cfg["API_KEY"] = ""
            self.cfg["API_BASE_URL"] = OPENROUTER_API_BASE
            self.cfg["MODEL"] = DEEPSEEK_MODEL
            self.cfg["AI_CONFIG_PROFILE"] = AI_CONFIG_PROFILE
            self.save_cfg(self.cfg)
        sm = ScreenManager()
        sm.add_widget(SettingsScreen(self))
        sm.add_widget(ChatScreen(self))
        sm.current = "chat" if all(self.cfg.get(k) for k in
                                   ("API_BASE_URL", "API_KEY", "MODEL")) else "settings"
        return sm

    def save_cfg(self, cfg):
        self.cfg = cfg
        with open(self.cfg_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False)


if __name__ == "__main__":
    XilianApp().run()
