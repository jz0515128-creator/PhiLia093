import sys
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import p4a_hook  # noqa: E402

SERVICE_XML = (ROOT / "android_manifest_service.xml").read_text(encoding="utf-8")
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

BASE = (
    '<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="p">\n'
    '<application android:label="a">\n<activity android:name=".A"/>\n</application>\n'
    "%s\n</manifest>"
)


def parse(text):
    return ET.fromstring(text)


class ManifestHookTests(unittest.TestCase):
    def assert_single_application_with_service(self, text):
        root = parse(text)
        applications = root.findall("application")
        self.assertEqual(len(applications), 1)
        services = applications[0].findall("service")
        self.assertEqual(len(services), 1)
        self.assertEqual(services[0].get(ANDROID_NS + "name"), p4a_hook.SERVICE_NAME)
        self.assertEqual(
            services[0].get(ANDROID_NS + "permission"),
            "android.permission.BIND_ACCESSIBILITY_SERVICE",
        )
        self.assertEqual(len(applications[0].findall("activity")), 1)

    def test_duplicate_application_wrapper_is_folded_in(self):
        """The original bug: service inside a second <application> that Android ignores."""
        broken = BASE % ("<application>\n" + SERVICE_XML + "\n</application>")
        self.assertEqual(len(parse(broken).findall("application")), 2)
        self.assert_single_application_with_service(p4a_hook.merge_service(broken, SERVICE_XML))

    def test_service_is_added_when_missing(self):
        self.assert_single_application_with_service(
            p4a_hook.merge_service(BASE % "", SERVICE_XML))

    def test_merge_is_idempotent(self):
        once = p4a_hook.merge_service(BASE % "", SERVICE_XML)
        self.assertEqual(p4a_hook.merge_service(once, SERVICE_XML), once)

    def test_manifest_without_application_is_rejected(self):
        with self.assertRaises(RuntimeError):
            p4a_hook.merge_service("<manifest></manifest>", SERVICE_XML)


if __name__ == "__main__":
    unittest.main()
