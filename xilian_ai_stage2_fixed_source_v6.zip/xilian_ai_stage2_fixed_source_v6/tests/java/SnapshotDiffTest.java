package org.xilian.xilianai;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class SnapshotDiffTest {
    private static void expect(String name, List<String> actual, String... expected) {
        List<String> want = Arrays.asList(expected);
        if (!actual.equals(want)) {
            throw new AssertionError(name + " expected=" + want + " actual=" + actual);
        }
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) {
        expect("append-only", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("a", "b", "c", "d")), "d");
        expect("same-text-new-message", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b"), Arrays.asList("a", "b", "b")), "b");
        expect("two-identical-new-messages", SnapshotDiff.computeFresh(
                Arrays.asList("a"), Arrays.asList("a", "x", "x")), "x", "x");
        expect("scroll-overlap", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("b", "c", "d")), "d");
        expect("unrelated-history-safe", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("x", "y", "z")));
        expect("partial-tail-updated-then-append", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "hel"), Arrays.asList("a", "b", "hello", "new")), "new");
        expect("insertion-not-misread-as-new", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b", "c"), Arrays.asList("a", "b", "x", "c")));
        expect("unchanged", SnapshotDiff.computeFresh(
                Arrays.asList("a", "b"), Arrays.asList("a", "b")));
        if (SnapshotDiff.findOverlap(Collections.emptyList(), Arrays.asList("a")) != 0) {
            throw new AssertionError("empty overlap should be zero");
        }
        System.out.println("PASS empty-overlap");
    }
}
