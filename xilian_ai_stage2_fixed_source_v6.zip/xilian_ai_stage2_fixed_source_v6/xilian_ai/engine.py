import json

import requests

from .persona import SYSTEM_PROMPT


class AIEngineError(RuntimeError):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


class AIEngine:
    def __init__(self, base_url, api_key, model, timeout=45):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key.strip()
        self.model = model.strip()
        self.timeout = timeout

    @staticmethod
    def _error_detail(response):
        try:
            payload = response.json()
        except ValueError:
            payload = None
        if isinstance(payload, dict):
            error = payload.get("error", payload)
            if isinstance(error, dict):
                detail = error.get("message") or error.get("code")
            elif isinstance(error, str):
                detail = error
            else:
                detail = None
            if detail:
                return str(detail)[:300]
        text = getattr(response, "text", "")
        return text.strip()[:300] if text else ""

    @classmethod
    def _raise_http_error(cls, response):
        status = response.status_code
        detail = cls._error_detail(response)
        suffix = f"（服務訊息：{detail}）" if detail else ""
        if status == 401:
            message = f"OpenRouter API Key 無效或未獲授權（HTTP 401）{suffix}"
        elif status == 429:
            message = f"OpenRouter 請求過於頻繁或額度不足（HTTP 429）{suffix}"
        elif status >= 500:
            message = f"OpenRouter 或上游模型服務暫時錯誤（HTTP {status}）{suffix}"
        else:
            message = f"OpenRouter 請求失敗（HTTP {status}）{suffix}"
        raise AIEngineError(message, status_code=status)

    def decide(self, message, context="", force_reply=False):
        if force_reply:
            prompt = (
                "這是使用者手動按下的功能測試，不是真實群聊自動回覆。"
                "請忽略重複內容判斷、是否需要回覆的判斷，也不要因為內容看起來像重複而拒答。"
                "請針對下面的測試文字，直接以昔涟口吻生成一句自然、簡短的繁體中文回覆。"
                "必須輸出 should_reply=true，reply 必須是非空文字。只輸出指定 JSON。\n\n"
                f"測試文字：\n{message}"
            )
        else:
            prompt = (
                "請判斷是否需要以昔涟身份回應這條群聊消息。"
                "只輸出指定 JSON。不要回覆自己的消息。"
                "可見文字可能因畫面重讀而重複；只有能確認是昔涟自己剛發過的內容時才應避免回覆，"
                "不要單憑文字片段重複就判定不回覆。\n\n"
                f"近期上下文：\n{context or '（暫無）'}\n\n"
                f"新消息：\n{message}"
            )
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "temperature": 0.8,
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": prompt},
                    ],
                    "response_format": {"type": "json_object"},
                },
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise AIEngineError(f"無法連線至模型服務：{exc}") from exc

        if response.status_code >= 400:
            self._raise_http_error(response)

        try:
            data = response.json()
        except ValueError as exc:
            raise AIEngineError("模型服務回應不是有效的 JSON。") from exc
        if not isinstance(data, dict):
            raise AIEngineError("模型服務回應格式錯誤：頂層資料不是 JSON 物件。")

        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise AIEngineError("模型服務回應缺少 choices/message/content 欄位。") from exc
        if not isinstance(content, str):
            raise AIEngineError("模型回覆格式錯誤：content 不是文字。")
        try:
            result = json.loads(content)
        except (TypeError, ValueError) as exc:
            raise AIEngineError("模型回覆不是有效的 JSON，請重試。") from exc
        if not isinstance(result, dict):
            raise AIEngineError("模型回覆格式錯誤：預期 JSON 物件。")

        result.setdefault("should_reply", False)
        result.setdefault("reason", "")
        result.setdefault("reply", "")
        if not isinstance(result["should_reply"], bool):
            result["should_reply"] = False
        if not isinstance(result["reason"], str):
            result["reason"] = ""
        if not isinstance(result["reply"], str):
            result["reply"] = ""
        if force_reply:
            # Manual test mode must demonstrate draft generation, not the chat policy.
            if result["reply"].strip():
                result["should_reply"] = True
            else:
                raise AIEngineError("測試模式下模型沒有生成草稿文字，請再次測試或檢查模型輸出。")
        elif not result["should_reply"]:
            result["reply"] = ""
        return result
