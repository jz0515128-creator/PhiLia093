"""Auto-reply policy that is independent of Kivy/Android so it can be unit tested.

Modes
-----
off    : never call the model for observed messages.
draft  : call the model, show the draft, send only after the user taps the send button.
auto   : call the model and queue the reply for sending automatically (guarded).
"""
import time

MODE_OFF = "off"
MODE_DRAFT = "draft"
MODE_AUTO = "auto"
MODES = (MODE_OFF, MODE_DRAFT, MODE_AUTO)

MODE_LABELS = {
    MODE_OFF: "回复：关闭",
    MODE_DRAFT: "回复：仅草稿",
    MODE_AUTO: "回复：自动发送",
}

MAX_REPLY_CHARS = 300
AUTO_MIN_INTERVAL_S = 30.0
MANUAL_MIN_INTERVAL_S = 5.0
MAX_SENDS_PER_HOUR = 20
DEBOUNCE_S = 4.0
MAX_BATCH_FRAGMENTS = 16


# Strong indicators that a visible fragment is app/diagnostic UI rather than a
# human chat message. Keep this deliberately narrow to avoid suppressing normal chat.
_INTERNAL_UI_MARKERS = (
    "診斷：待處理", "诊断：待处理", "原生自動發送開關", "本機觀察歷史", "可見文字觀察記錄",
    "已排入發送隊列", "模型請求失敗", "連線測試失敗", "OpenRouter API",
    "回复：自动发送", "回复：仅草稿", "回复：关闭", "昔涟思考中",
    "昔涟（草稿）", "昔涟（自動發送中）", "昔涟 AI ·",
)

def is_internal_ui_text(value):
    """Reject obvious app diagnostics accidentally observed as chat content."""
    text = " ".join(str(value or "").split())
    if not text:
        return True
    return any(marker.casefold() in text.casefold() for marker in _INTERNAL_UI_MARKERS)


DEFAULT_REPLY_MODE = MODE_AUTO


def normalize_mode(value):
    """A missing setting uses the default; an unrecognised stored value fails safe to off."""
    if value is None:
        return DEFAULT_REPLY_MODE
    return value if value in MODES else MODE_OFF


def next_mode(mode):
    order = list(MODES)
    return order[(order.index(normalize_mode(mode)) + 1) % len(order)]


def clean_reply(text, limit=MAX_REPLY_CHARS):
    """Reduce a model reply to a single safe chat line."""
    text = " ".join(str(text or "").split())
    return text[:limit].strip()


class SendGate:
    """Cooldown and hourly cap for outgoing replies (Python-side policy).

    The Java service enforces its own hard limits too; this gate only avoids
    spending API calls on replies that could not be sent anyway.
    """

    def __init__(self, clock=time.time):
        self._clock = clock
        self._sent = []

    def _prune(self, now):
        self._sent = [t for t in self._sent if now - t < 3600.0]

    def check(self, automatic):
        """Return (allowed, reason)."""
        now = self._clock()
        self._prune(now)
        if len(self._sent) >= MAX_SENDS_PER_HOUR:
            return False, "已达到每小时发送上限"
        min_interval = AUTO_MIN_INTERVAL_S if automatic else MANUAL_MIN_INTERVAL_S
        if self._sent and now - self._sent[-1] < min_interval:
            wait = int(min_interval - (now - self._sent[-1])) + 1
            return False, f"冷却中，约 {wait} 秒后可再次发送"
        return True, ""

    def record(self):
        self._sent.append(self._clock())


class MessageBatcher:
    """Collect fresh fragments and release them as one batch after a quiet period."""

    def __init__(self, clock=time.time, quiet_s=DEBOUNCE_S, max_items=MAX_BATCH_FRAGMENTS):
        self._clock = clock
        self._quiet_s = quiet_s
        self._max_items = max_items
        self._items = []
        self._last_add = 0.0

    def add(self, text):
        text = str(text or "").strip()
        if not text or is_internal_ui_text(text):
            return
        # Repeated identical text can be two legitimate consecutive chat messages.
        # The native snapshot diff is responsible for event-level duplicate control.
        # max_items caps one API request, not the total queue. Keep FIFO backlog so
        # a burst larger than one batch does not silently lose its earliest messages.
        self._items.append(text)
        self._last_add = self._clock()

    def ready(self):
        return bool(self._items) and self._clock() - self._last_add >= self._quiet_s

    def take(self):
        items = self._items[:self._max_items]
        self._items = self._items[len(items):]
        return items

    def clear(self):
        self._items = []
        self._last_add = 0.0

    def __len__(self):
        return len(self._items)
