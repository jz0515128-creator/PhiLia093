> **历史阶段报告（V1/阶段 1）：** 本文记录的是早期“只观察、不发送”的阶段，不代表当前 V5 功能。最新修复、测试与限制请以 `AUDIT_V5.md` 和 `README.md` 的 V5 部分为准。

# 昔涟 AI 抖音普通个人账号辅助接入 — 阶段 1 报告

## 交付与构建

- 产物：`bin/xilianai-1.0-arm64-v8a-debug.apk`
- 包名：`org.xilian.xilianai`
- 架构：`arm64-v8a`；最低 Android API 24，target API 33
- 构建：Buildozer/Gradle Debug，`BUILD SUCCESSFUL in 2s`
- APK 大小：19,068,486 bytes
- SHA-256：`29f3e070446746fc8e7824b342f8883fad9b11d4101dc18eeea45d34b3a4f57e`
- 签名和 APK ZIP 完整性检查通过；Manifest 中已合并 `DouyinAccessibilityService`，DEX 中包含服务和 `ObserverControl` 类。
- 最终构建日志：`/home/ubuntu/work/build-stage1-final.log`

## 已实现

工程仍基于 Kivy/Python，保留昔涟提示词、OpenRouter DeepSeek 配置、中文输入与原 SQLite 对话记忆。新增 Android 原生 `AccessibilityService` 和单独的观察片段 SQLite 表。Manifest 服务使用 `BIND_ACCESSIBILITY_SERVICE`，只订阅包名 `com.ss.android.ugc.aweme`；用户必须自行在 Android 辅助功能设置启用服务，再在昔涟 AI 内点击「开始观察」。App 内「暂停观察」会关闭收集开关，「清空观察」会删除本地片段及待同步队列。

观察服务仅在上述两个开关均已启用后工作。它要求可见节点同时包含群聊标记和可编辑输入框；只处理非密码、非编辑的可见文字叶节点，不调用模型，不点击、手势操作、填入或发送任何抖音消息。片段携带会话窗口标识、发送者（目前留空）、本地观察时间、0.45 的保守置信度和“可见文字片段/不保证完整”状态。事件重复会在短时间窗口去重；待同步队列最多 200 条，溢出会计数并在界面提示。内容保存在应用私有 SharedPreferences 队列并同步至应用私有 SQLite，不写入调试日志。

## 自动化测试记录

命令：

```text
KIVY_NO_ARGS=1 KIVY_LOG_LEVEL=warning SDL_VIDEODRIVER=dummy python3 -m unittest discover -s tests -v
```

结果：22 项运行，21 项通过，1 项跳过。通过项覆盖既有中文拼音/输入和 OpenRouter 错误处理、新增服务 Manifest/抖音包名范围/无点击发送接口的静态检查，以及 SQLite 中文标点、时间/置信度/状态、重复片段去重和清除隔离测试。跳过的是可选的真实 OpenRouter 连线测试，因为未配置用户金钥。测试记录：`/home/ubuntu/work/test-stage1-final.log`。

## 已知限制与未验证事项

当前云环境没有连接 Android 设备，且无 `/dev/kvm`，因此没有安装 APK，也没有在真实抖音群聊启用 AccessibilityService。不能据此声称已经验证消息读取、后台实时监听或可靠群聊识别。

识别目前是保守启发式：抖音页面必须暴露“群聊/群组/多人聊天”一类可见标记及可编辑节点；实际抖音版本可能不提供这些文字或可访问节点，届时界面会显示“无法确认/不可读取”，不保存页面文字。即使进入“疑似群聊”，读取也只是当前可见的非密码文字片段，可能混有标题或其他控件文字，消息可能不完整，发送者不识别，不能作为完整会话记录。尚未在设备上测试页面切换、锁屏/返回前台、服务中断恢复、连续消息及真实重复消息行为；设备测试前保持阶段 1，不启用自动发言。没有官方 API，也未使用私有协议或登录凭证。
