# 昔涟 AI · Android 版

首次打开或升级后在「设置」页填入 OpenRouter API Key。默认 API Base URL 为
`https://openrouter.ai/api/v1`，模型为 `deepseek/deepseek-v4.1-flash`；应用会请求
`/chat/completions`，并以 Bearer Token 认证。金钥由使用者在密码遮蔽输入框中自行设置，
不会写入源码或打包进 APK，配置保存在 Android 应用私有目录中。

「测试 OpenRouter 连接」会发送「群友：你好，昔涟」，并要求模型返回中文回复。若旧配置
使用的不是 OpenRouter，升级迁移会清除旧 API Key，避免把其他服务的金钥发送给 OpenRouter；
请在设置页重新输入 OpenRouter Key。HTTP 401、429、5xx 和无效 JSON 会显示可读错误；
请求失败时，聊天输入内容会保留以供重试。

应用保留昔涟人格、DeepSeek 配置、对话记忆和聊天界面。

## 阶段 1：可见文字观察

需先由用户在 Android「无障碍/辅助功能」系统设置中主动启用「昔涟 AI 抖音群聊助手」，
再回到 App 按「开始观察」。「暂停观察」是全局观察开关；「清空观察」会清理本地片段与待同步队列。
服务订阅大陆抖音与常见国际版 TikTok 包名，并要求页面出现群聊标记（含部分群成员数标题格式）及可编辑输入框才记录；
不读取密码节点、Cookie 或登录凭证。识别是启发式的，发送者无法确认，内容可能不完整。

阶段 2 起，观察不再每隔几秒重复记录整屏文字：第一次看到某个群聊页面只记一次「基线」，
之后由快照差分判定新可见文字。底部追加和滚动重叠可识别；页面发生无重叠重排时会保守重设基线，不触发自动回复。

## 阶段 2：回复（默认自动发送）

聊天页右上角的按钮在三种模式间切换。首次启动默认「自动发送」，但仍需你先在系统无障碍里启用服务并按「开始观察」才会生效，启动时聊天页会显示一条说明：

| 模式 | 行为 |
| --- | --- |
| 回复：关闭 | 不调用模型，不发送任何消息 |
| 回复：仅草稿 | 新消息安静 4 秒后调用模型生成草稿；按「发送到抖音」才会发出 |
| 回复：自动发送（默认） | 草稿通过限制检查后自动发出；从其他模式手动切回时会弹风险确认 |

发送方式：服务在抖音群聊输入框填入文字（`ACTION_SET_TEXT`），再点击「发送」按钮。若输入框拒绝直接填字，
会改用「复制到剪贴板再粘贴」，这时你的剪贴板内容会被回复文字覆盖。不使用手势，不操作其他应用。以下限制在原生层强制执行，不只是界面约定：

- 只在抖音群聊页面、且能识别输入框时发送；不在页面上时最多等 2 分钟，之后自动取消。
- 输入框里已有你自己的文字时不覆盖，直接放弃本条。
- 点击发送前会核对输入框内容与待发文字完全一致。
- 自动模式冷却 30 秒，手动确认冷却 5 秒；每小时最多 20 条；单条最长 300 字。
- 自己刚发出的文字（30 分钟内）不会被当作新消息再回复。
- 自动发送开关只有在系统无障碍服务已启用时才能打开；服务断开时清除待发回复。

**已知限制：** 无法区分群友和你自己的新消息（发送者未知），你本人在群里发的话也可能触发回复；
群聊页面结构、「发送」按钮文字和输入框是否接受 `ACTION_SET_TEXT` 取决于抖音版本，
失败时界面会显示原因，文字可能留在输入框中需要手动发送。自动化操作可能违反平台规则并影响账号。
本版本**尚未在真实设备和真实抖音群聊上验证**。

## 排查：看得到新消息但没有回复

聊天页的「回复」行会实时显示待处理队列、原生自动发送开关和最近一步（侦测新文字 / 呼叫模型 / 模型选择不回应 / 已排入发送 / 失败原因）。服务状态会区分目标窗口不可读、群聊标记/输入框不符合、建立基线、没有新增文字、文字变化无法安全判定等情况。观察记录会标注【新消息】或【基线】；只有【新消息】会进入回复队列。「测试」按钮用最近一条观察文字生成草稿（不会自动发送）。模型 API 请求失败时，失败批次不会无限自动重试，会保留在独立队列，并显示「重试这批新消息」按钮；API 尚未配置时，新消息不会被提前丢弃。

## 清单修复（无障碍服务找不到的问题）

旧版把 `<service>` 包在 `<application>` 里并通过 `android.extra_manifest_xml` 注入，而该选项写在
`<manifest>` 根下，结果生成第二个 `<application>`，Android 忽略它，服务从未注册。现在改为
`p4a_hook.py`（`p4a.hook`）在组装 APK 前把 `android_manifest_service.xml` 合并进唯一的
`<application>`，合并结果不合格会直接让构建失败；CI 还会用 `aapt` 检查 APK 里恰好有一个
`<application>` 且包含服务。

测试（不依赖 Android）：`python -m unittest tests.test_autoreply tests.test_manifest_hook tests.test_accessibility_integration tests.test_observation_store tests.test_openrouter_engine`；
含 Kivy 的 `test_ime_input` 需在装有 Kivy 的环境运行：
`KIVY_NO_ARGS=1 KIVY_LOG_LEVEL=warning SDL_VIDEODRIVER=dummy python3 -m unittest discover -s tests -v`

## 生成 APK（任选其一）
1. GitHub：新建仓库 → 上传本目录全部文件（含 .github）→ Actions → Build APK → 运行完成后在 Artifacts 下载 apk（首次约 20–40 分钟）。
2. 本地：Linux/WSL 中 `pip install buildozer cython==0.29.36 && buildozer android debug`，apk 在 bin/。


## 阶段 2 修复补丁（自动回复链路）

- 新增 Python 与原生层双重诊断文字过滤，明显属于昔涟 AI 状态栏/回复面板的文字不会保存成观察记录，也不会触发回复。
- 观察到的片段因发送者未确认，不再自动写入持久 AI 对话记忆，避免后台/界面文字污染上下文；只有成功发送的昔涟回复仍会写入记忆。
- 自动回复队列不会仅因文字相同就去重；两条内容完全相同的连续消息会保留为两个独立片段。
- 保留目标应用包名、群聊页面标记、输入框校验、自动发送开关、冷却与每小时上限。

注意：无障碍可见文本并不总能可靠识别抖音每条气泡的发送者；本补丁过滤明显内部诊断文字，但不能保证在所有抖音版本中准确区分群友和用户自己的普通发言。发送流程仍须在真实设备群聊中验证。


## V4 observation-detection fix

- Fixed the common append-only snapshot diff case: when visible chat text changes from `[a, b, c]` to `[a, b, c, d]`, the old suffix-to-prefix-only comparison returned no fresh messages. The observer now recognizes the previous snapshot as a prefix and emits the appended fragment(s), while retaining the scroll-overlap path.
- Added a regression assertion for the append-only branch.
- This is a source change, not a rebuilt or device-verified APK. If no observations appear after installing a build made from this source, inspect the in-app observer status for `群标记` and `输入框`; if the app never enters the supported-package event handler, verify the installed Douyin package ID and that the service XML in the installed APK contains it.


## V5 完整排查与回归修复

- 新增纯 Java `SnapshotDiff` 并用可执行回归测试覆盖：底部追加、滚动重叠、连续同文消息、末条文字逐步更新后追加、插入历史不误判以及无重叠安全回退。
- 保留相同文字消息的独立事件；快照节点列表不再用集合去重。Android 事件序号用于观察记录幂等写入，短时间内真实重复消息不会被本地历史去重规则吞掉。
- 群聊识别只接受页面上方约 18% 区域的群聊标记；会话签名只取上方约 14% 区域，减少把滚动消息误当标题。输入框须是非密码且位于屏幕下半部的可编辑节点；服务状态会显示可读节点数。
- 识别到群聊后每秒检查一次可见目标窗口；优先活动窗口，系统输入法短暂抢焦点时只检查 Android 报告为活动/焦点的可交互窗口，不扫描任意后台窗口。连续读取失败 3 次后停止轮询，等待下一次目标应用事件。
- 群聊标题变化或离开已识别页面会重置基线，减少把历史消息当成新消息；暂时读不到文字时保留最后一个可信快照。
- API 未填写时保留待处理消息；请求失败时提供单独的手动重试队列，不无限重复调用 API，也不会把旧失败批次混入新消息。每个请求最多 16 条，但超过 16 条的积压会按先入先出拆批，不再静默丢掉队头。
- 暂停观察时清空快照，恢复后重新建立基线，避免把暂停期间累积的消息误当成新消息；关闭回复模式会取消所有原生待发项，包括已经点过发送的草稿。
- **验证边界：** 已在开发容器通过 Python 单元测试与纯 Java 快照测试；当前环境没有 Android SDK/Buildozer，不能在这里重建 APK，也无法验证你的 OPPO Reno11 Pro 上具体抖音版本的无障碍节点结构。实际安装必须用本 V5 源码重新构建 APK。


## V6 群聊识别回归修复

V6 修复 V5 过窄的群聊页头识别范围（18% 扩为 35%）和识别失败后停止轮询的问题。识别失败状态会展示页头候选文字与可读节点数，方便继续针对真机 UI 排查。此源码仍需重新构建 APK 并在实际抖音版本验证。
